# Slope Lab — Interactive Linear Regression Learning Platform

> *"Understand how a model learns from data."*

Slope Lab is a full-stack, pedagogical machine learning laboratory designed to teach students the entire workflow of training an empirical **Linear Regression** model. From raw tabular dataset ingestion and statistical profiling to data cleaning, feature scaling, categorical encoding, train-test splitting, Ordinary Least Squares (OLS) fitting, diagnostic evaluation, and live interactive predictions.

---

## Key Architecture & Features

### 1. Empirical Machine Learning Pipeline (Python Backend)
- **Zero Fabrication**: All calculations, statistics, splits, transformations, fitting, and predictions occur on the live Python FastAPI backend.
- **Strict Data Leakage Prevention**: Train-test splits occur *before* fitting imputers, scalers, and encoders. Preprocessing parameters are learned solely from the training partition and applied unchanged to test sets and future inference.
- **Comprehensive Scikit-Learn Integration**: Uses `Pipeline` and `ColumnTransformer` to pair estimators (`LinearRegression`, `Ridge`, `Lasso`) with robust preprocessing pipelines.
- **Transparent Linear Decompositions**: Prediction responses return not just $\hat{y}$, but the full term-by-term decomposition:
  $$\hat{y} = \beta_0 + \sum_{j=1}^p (\beta_j \cdot z_j)$$

### 2. Analytical & Editorial User Experience (React + Vite)
- **Academic Aesthetic**: Clean, high-density layout with white surfaces, near-black slate typography, restrained corner radii, thin borders, and a calm indigo accent.
- **7-Stage Guided Workflow**:
  1. **Dataset Import**: Curated sample datasets (Real Estate Prices, Student Exam Grades, Advertising Revenue), multi-format file uploader (CSV, Excel, JSON), or spreadsheet-like manual data entry.
  2. **Inspect & Profile**: Column-level statistical profiling (mean, median, standard deviation, quartiles, category frequencies) and automated health diagnostics (identifiers, high cardinality, constant variance, missingness).
  3. **Feature Selection**: Independent input predictor ($X$) selection and single numeric target ($y$) designation with leakage and collinearity checks.
  4. **Preprocessing**: Configurable missing-value imputation (Mean, Median, Mode, Constant), feature scaling (`StandardScaler`, `MinMaxScaler`, `RobustScaler`, `MaxAbsScaler`), and categorical encoding (`OneHotEncoder`, `OrdinalEncoder`).
  5. **Split & Model Configuration**: Interactive train/test partition slider with instant row-count recalculations, reproducible random seeds, chronological split mode, and model hyperparameter toggles (`fit_intercept`, `positive`, Ridge/Lasso regularization with $\alpha$).
  6. **Train & Scientific Dashboard**: Real-time evaluation reporting $R^2$ (unbounded, supporting negative values), MAE, MSE, and RMSE on both test and train sets; interactive Recharts visualizations (Actual vs. Predicted, Residuals vs. Predicted, Residual Error Distribution Histogram, and Horizontal Coefficient Magnitudes); and grounded empirical insights.
  7. **Prediction Playground**: Dynamically generated input form allowing students to enter custom values, execute live inference against the saved model pipeline, and inspect feature-level contributions.
- **Experiment History & Tracking**: Log, inspect, and compare multiple model runs with different preprocessing and hyperparameter settings.

---

## Technology Stack

- **Frontend**:
  - React 19 + TypeScript + Vite
  - Tailwind CSS (Tailored Academic Design System)
  - Recharts (Interactive SVG Charts)
  - Lucide React (Icons)
  - Vitest + React Testing Library
- **Backend**:
  - Python 3.10+
  - FastAPI (REST API with CORS)
  - pandas (Tabular data handling and inspection)
  - NumPy & SciPy (Numerical linear algebra and distributions)
  - scikit-learn (ColumnTransformer, Pipeline, LinearRegression, Ridge, Lasso)
  - openpyxl (Excel parsing support)
  - pytest + httpx (Automated testing suite)

---

## Getting Started

### Prerequisites
- Python 3.10 or higher
- Node.js 18+ and npm

### 1. Backend Setup
From the project root:

```bash
# Navigate to backend directory
cd backend

# Create and activate virtual environment
python -m venv venv

# Windows:
.\venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Start the FastAPI backend server
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
The backend API documentation is available at `http://127.0.0.1:8000/docs`.

### 2. Frontend Setup
In a new terminal window, from the project root:

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start Vite development server
npm run dev
```
Open your browser and navigate to:
```
http://127.0.0.1:5173/
```

---

## Supported File Formats

Slope Lab validates file formats case-insensitively by extension and verifies content integrity:
- **CSV (`.csv`)**: Comma-separated values with automatic encoding fallback (UTF-8, Latin-1).
- **Excel (`.xlsx`, `.xls`)**: Spreadsheets parsed via pandas and openpyxl engines.
- **JSON (`.json`)**: Tabular JSON structures including array of records `[ {...}, {...} ]` or dictionary with `data` / `records` keys.
- **Manual Entry**: Interactive spreadsheet grid with add/remove row/column controls, column renaming, custom data typing, and copy-paste support from Excel/Google Sheets.

---

## Running Automated Tests

### Backend Unit & Integration Tests (pytest)
Runs 12 comprehensive test cases covering file parsing, profiling, data leakage prevention, edge case handling, Ridge/Lasso models, and out-of-distribution category predictions:

```bash
cd backend
.\venv\Scripts\pytest -o pythonpath=. -v tests
```

### Frontend Automated Tests (Vitest)
Runs component tests covering Header, Workflow Navigation, Manual Spreadsheet Editor, Feature Selector, Split Slider calculations, and Evaluation summaries:

```bash
cd frontend
npm test
```

---

## Machine Learning Correctness Checklist

- [x] **No Data Leakage**: Split occurs prior to fitting any transformer.
- [x] **Safe Inference Pipeline**: Saved models package both the fitted `ColumnTransformer` and the estimator in a single `joblib` artifact.
- [x] **Unclamped $R^2$**: $R^2$ values are reported truthfully, allowing negative values if the model generalizes worse than predicting the mean.
- [x] **Out-of-Vocabulary Category Handling**: One-hot encoders configured with `handle_unknown='ignore'` so unseen prediction categories do not crash inference.
- [x] **Missing Target Protection**: Observations with null or non-finite target values are dropped prior to fitting.
- [x] **Reproducibility**: Explicit random seed parameter wired through to `train_test_split` and regularized estimators.
- [x] **Chronological Splitting**: Supports non-shuffled ordered partitions for time-series datasets.

---

## License
MIT License. Built for machine learning education and pedagogical exploration.
