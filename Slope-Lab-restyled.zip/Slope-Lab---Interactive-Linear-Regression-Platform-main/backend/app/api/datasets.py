"""API endpoints for dataset uploading, manual entry, sample loading, and profiling."""
from typing import List
from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from app.schemas.dataset import (
    DatasetPreviewResponse,
    DatasetProfile,
    ManualDatasetCreate,
    SampleDatasetInfo,
)
from app.services.dataset_service import SAMPLE_CATALOG, dataset_service

router = APIRouter(prefix="/api/datasets", tags=["datasets"])

@router.get("/samples", response_model=List[SampleDatasetInfo])
def list_sample_datasets():
    """List available built-in sample datasets for immediate learning."""
    return SAMPLE_CATALOG

@router.post("/samples/{sample_id}/load", response_model=DatasetProfile)
def load_sample_dataset(sample_id: str):
    """Load a built-in sample dataset into the active workspace."""
    dataset_service.load_sample(sample_id)
    return dataset_service.get_profile(sample_id)

@router.post("/upload", response_model=DatasetProfile)
def upload_dataset(file: UploadFile = File(...)):
    """Upload a dataset file (CSV, Excel, JSON)."""
    return dataset_service.upload_dataset(file)

@router.post("/manual", response_model=DatasetProfile)
def create_manual_dataset(data: ManualDatasetCreate):
    """Create a dataset from manual spreadsheet-like input."""
    return dataset_service.create_manual_dataset(data)

@router.get("/{dataset_id}/profile", response_model=DatasetProfile)
def get_dataset_profile(dataset_id: str):
    """Retrieve detailed column statistics and health issues for a dataset."""
    return dataset_service.get_profile(dataset_id)

@router.get("/{dataset_id}/preview", response_model=DatasetPreviewResponse)
def get_dataset_preview(
    dataset_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=5, le=100),
):
    """Retrieve paginated tabular rows for dataset inspection."""
    return dataset_service.get_preview(dataset_id, page=page, page_size=page_size)

@router.delete("/{dataset_id}")
def delete_dataset(dataset_id: str):
    """Delete a dataset and clear cached assets."""
    success = dataset_service.delete_dataset(dataset_id)
    return {"success": success, "dataset_id": dataset_id}
