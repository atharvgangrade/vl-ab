"""API endpoints for experiment validation, model training, evaluation results, and prediction."""
from typing import Any, Dict, List
from fastapi import APIRouter
from app.schemas.experiment import (
    ExperimentCreate,
    ExperimentResult,
    PredictRequest,
    PredictResponse,
    ValidationResponse,
)
from app.services.experiment_service import experiment_service

router = APIRouter(prefix="/api/experiments", tags=["experiments"])

@router.post("/validate", response_model=ValidationResponse)
def validate_experiment(config: ExperimentCreate):
    """Validate configuration and feature selection before training."""
    return experiment_service.validate_configuration(config)

@router.post("/train", response_model=ExperimentResult)
def train_experiment(config: ExperimentCreate):
    """Execute training pipeline strictly fitted on train split and return scientific evaluation results."""
    return experiment_service.train_experiment(config)

@router.get("", response_model=List[Dict[str, Any]])
def list_experiments():
    """List historical experiment runs."""
    return experiment_service.list_experiments()

@router.get("/{experiment_id}", response_model=ExperimentResult)
def get_experiment(experiment_id: str):
    """Retrieve full evaluation metrics, chart points, and coefficients for an experiment."""
    return experiment_service.get_experiment(experiment_id)

@router.post("/{experiment_id}/predict", response_model=PredictResponse)
def predict_with_experiment(experiment_id: str, request: PredictRequest):
    """Generate prediction using saved fitted pipeline and return feature contribution breakdown."""
    return experiment_service.predict(experiment_id, request)
