"""Slope Lab FastAPI Application."""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.api.datasets import router as datasets_router
from app.api.experiments import router as experiments_router

app = FastAPI(
    title="Slope Lab API",
    description="Interactive Linear Regression Laboratory Backend",
    version="1.0.0",
)

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global error handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal Server Error: {str(exc)}"},
    )

# Routers
app.include_router(datasets_router)
app.include_router(experiments_router)

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "service": "Slope Lab Backend",
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
