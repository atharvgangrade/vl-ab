"""Dataset profiler that inspects, summarizes, and detects issues in tabular data."""
import math
from typing import Any, Dict, List, Tuple
import numpy as np
import pandas as pd
from app.schemas.dataset import CategoryFrequency, ColumnProfile, DatasetProfile, NumericStats

def infer_column_type(series: pd.Series, col_name: str) -> Tuple[str, List[str]]:
    """Infer semantic column type and detect issues."""
    issues: List[str] = []
    col_lower = str(col_name).lower()
    total_len = len(series)
    non_null_series = series.dropna()
    unique_count = non_null_series.nunique()
    
    if total_len == 0 or len(non_null_series) == 0:
        return "categorical", ["Column is completely empty"]

    # 1. Check for identifier
    is_id_name = any(k in col_lower for k in ["id", "uuid", "identifier", "index", "pk"])
    if is_id_name and unique_count == len(non_null_series) and unique_count > 10:
        issues.append("High probability of being an identifier column (not useful for prediction).")
        return "identifier", issues

    # 2. Check for boolean
    if pd.api.types.is_bool_dtype(series):
        return "boolean", issues
    if unique_count <= 2:
        unique_vals = set(str(v).strip().lower() for v in non_null_series.unique())
        if unique_vals.issubset({"true", "false", "0", "1", "yes", "no", "y", "n"}):
            return "boolean", issues

    # 3. Check for numeric
    if pd.api.types.is_numeric_dtype(series):
        # Check if actually an integer sequence ID
        if is_id_name and unique_count == len(non_null_series):
            issues.append("Sequential or unique integer identifier.")
            return "identifier", issues
        
        # Check for constant column
        if unique_count == 1:
            issues.append("Constant column (zero variance, provides no learning signal).")
        
        # Check for infinite values
        inf_count = np.isinf(non_null_series).sum()
        if inf_count > 0:
            issues.append(f"Contains {inf_count} infinite values.")

        return "numeric", issues

    # 4. Check if string/object might actually be numeric
    if pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series):
        # Try converting sample to numeric
        sample = non_null_series.head(100)
        num_converted = pd.to_numeric(sample, errors="coerce")
        if num_converted.notna().sum() / len(sample) > 0.85:
            issues.append("Appears to contain numeric values stored as text. Consider type conversion.")
            return "numeric", issues

    # 5. Check for datetime
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime", issues
    if pd.api.types.is_object_dtype(series) and any(k in col_lower for k in ["date", "time", "timestamp"]):
        try:
            pd.to_datetime(non_null_series.head(20), errors="raise")
            return "datetime", issues
        except Exception:
            pass

    # 6. Categorical
    if unique_count > 40 and unique_count / len(non_null_series) > 0.6:
        issues.append("High cardinality (>40 unique categories). One-hot encoding may cause feature explosion.")
    
    if unique_count == 1:
        issues.append("Single category throughout entire dataset (zero variance).")

    return "categorical", issues


def profile_dataset(df: pd.DataFrame, dataset_id: str, dataset_name: str, file_format: str, created_at: str) -> DatasetProfile:
    """Generate comprehensive profiling metrics and diagnostic checks for a dataset."""
    total_rows = len(df)
    total_cols = len(df.columns)
    duplicate_rows = int(df.duplicated().sum()) if total_rows > 0 else 0
    has_missing_values = bool(df.isna().sum().sum() > 0)

    column_profiles: List[ColumnProfile] = []

    for col in df.columns:
        series = df[col]
        missing_count = int(series.isna().sum())
        missing_pct = round((missing_count / total_rows * 100) if total_rows > 0 else 0.0, 2)
        non_null = series.dropna()
        unique_count = int(non_null.nunique())
        unique_pct = round((unique_count / total_rows * 100) if total_rows > 0 else 0.0, 2)

        inferred_type, issues = infer_column_type(series, str(col))

        if missing_pct >= 20.0:
            issues.append(f"High missing values: {missing_pct}% missing ({missing_count} rows).")

        numeric_stats: Optional[NumericStats] = None
        top_categories: Optional[List[CategoryFrequency]] = None

        # Sample values for preview
        sample_vals = [None if pd.isna(v) else (float(v) if isinstance(v, (np.floating, float)) else str(v)) 
                       for v in non_null.head(5).tolist()]

        if inferred_type == "numeric":
            # Coerce to numeric for stats
            num_series = pd.to_numeric(non_null, errors="coerce").dropna()
            # Drop infs
            num_series = num_series[np.isfinite(num_series)]
            if len(num_series) > 0:
                q25 = float(num_series.quantile(0.25))
                q75 = float(num_series.quantile(0.75))
                std_val = float(num_series.std()) if len(num_series) > 1 else 0.0
                if math.isnan(std_val):
                    std_val = 0.0

                numeric_stats = NumericStats(
                    min=round(float(num_series.min()), 4),
                    max=round(float(num_series.max()), 4),
                    mean=round(float(num_series.mean()), 4),
                    median=round(float(num_series.median()), 4),
                    std=round(std_val, 4),
                    q25=round(q25, 4),
                    q75=round(q75, 4),
                )
        else:
            # Categorical / boolean / other frequencies
            value_counts = non_null.astype(str).value_counts().head(10)
            top_cats: List[CategoryFrequency] = []
            for val, count in value_counts.items():
                cat_pct = round((count / len(non_null) * 100) if len(non_null) > 0 else 0.0, 1)
                top_cats.append(CategoryFrequency(value=str(val), count=int(count), percentage=cat_pct))
            top_categories = top_cats

        column_profiles.append(
            ColumnProfile(
                name=str(col),
                dtype=str(series.dtype),
                inferred_type=inferred_type,
                missing_count=missing_count,
                missing_percentage=missing_pct,
                unique_count=unique_count,
                unique_percentage=unique_pct,
                sample_values=sample_vals,
                numeric_stats=numeric_stats,
                top_categories=top_categories,
                issues=issues,
            )
        )

    return DatasetProfile(
        id=dataset_id,
        name=dataset_name,
        format=file_format,
        row_count=total_rows,
        column_count=total_cols,
        duplicate_row_count=duplicate_rows,
        has_missing_values=has_missing_values,
        columns=column_profiles,
        created_at=created_at,
    )
