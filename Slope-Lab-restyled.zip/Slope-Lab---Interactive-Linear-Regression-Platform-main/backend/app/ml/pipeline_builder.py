"""Pipeline construction and training adhering strictly to ML correctness without data leakage."""
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Lasso, LinearRegression, Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    MaxAbsScaler,
    MinMaxScaler,
    OneHotEncoder,
    OrdinalEncoder,
    RobustScaler,
    StandardScaler,
)
from app.schemas.experiment import (
    CoefficientItem,
    ModelConfig,
    PreprocessingConfig,
)

def create_numeric_transformer(
    imputer_strategy: str,
    constant_val: Any,
    scaler_strategy: str
) -> Pipeline:
    """Create a pipeline for a group or single numeric feature."""
    steps = []
    
    # 1. Imputation step
    if imputer_strategy == "mean":
        steps.append(("imputer", SimpleImputer(strategy="mean")))
    elif imputer_strategy == "median":
        steps.append(("imputer", SimpleImputer(strategy="median")))
    elif imputer_strategy == "constant":
        fill = 0.0
        try:
            fill = float(constant_val) if constant_val is not None else 0.0
        except (ValueError, TypeError):
            fill = 0.0
        steps.append(("imputer", SimpleImputer(strategy="constant", fill_value=fill)))
    else:
        # Default fallback or passthrough
        steps.append(("imputer", SimpleImputer(strategy="median")))

    # 2. Scaling step
    if scaler_strategy == "standard":
        steps.append(("scaler", StandardScaler()))
    elif scaler_strategy == "minmax":
        steps.append(("scaler", MinMaxScaler()))
    elif scaler_strategy == "robust":
        steps.append(("scaler", RobustScaler()))
    elif scaler_strategy == "maxabs":
        steps.append(("scaler", MaxAbsScaler()))
    # if 'none', no scaler is added

    return Pipeline(steps=steps)


def create_categorical_transformer(
    imputer_strategy: str,
    constant_val: Any,
    encoder_strategy: str,
    ordinal_order: Optional[List[str]] = None,
    handle_unknown: str = "ignore"
) -> Pipeline:
    """Create a pipeline for categorical features."""
    steps = []

    # 1. Imputation step
    if imputer_strategy == "constant":
        fill = str(constant_val) if constant_val is not None else "missing"
        steps.append(("imputer", SimpleImputer(strategy="constant", fill_value=fill)))
    else:
        steps.append(("imputer", SimpleImputer(strategy="most_frequent")))

    # 2. Encoding step
    if encoder_strategy == "ordinal":
        categories = [ordinal_order] if ordinal_order and len(ordinal_order) > 0 else "auto"
        steps.append((
            "encoder",
            OrdinalEncoder(
                categories=categories,
                handle_unknown="use_encoded_value",
                unknown_value=-1
            )
        ))
    elif encoder_strategy == "onehot":
        # Check sklearn version for sparse_output support
        try:
            ohe = OneHotEncoder(sparse_output=False, handle_unknown=handle_unknown)
        except TypeError:
            ohe = OneHotEncoder(sparse=False, handle_unknown=handle_unknown)
        steps.append(("encoder", ohe))
    else:
        # If none, fallback to ordinal so linear models can process it
        steps.append((
            "encoder",
            OrdinalEncoder(
                handle_unknown="use_encoded_value",
                unknown_value=-1
            )
        ))

    return Pipeline(steps=steps)


def build_preprocessor(
    df_sample: pd.DataFrame,
    input_features: List[str],
    preprocessing: PreprocessingConfig,
    inferred_types: Dict[str, str]
) -> ColumnTransformer:
    """Build scikit-learn ColumnTransformer from user configuration."""
    transformers = []

    # Group features by their configuration to create clean, optimized pipelines
    for feature in input_features:
        inf_type = inferred_types.get(feature, "numeric")
        has_encoding = (
            feature in preprocessing.encoding_strategies
            and preprocessing.encoding_strategies[feature] in ("onehot", "ordinal")
        )
        
        if has_encoding or inf_type in ("categorical", "boolean", "identifier", "datetime"):
            imp_strat = preprocessing.missing_value_strategies.get(feature, "most_frequent")
            const_val = preprocessing.missing_value_constants.get(feature, "missing")
            enc_strat = preprocessing.encoding_strategies.get(feature, "onehot")
            ord_order = preprocessing.ordinal_orders.get(feature, None)
            
            pipe = create_categorical_transformer(
                imp_strat,
                const_val,
                enc_strat,
                ord_order,
                preprocessing.handle_unknown_categorical
            )
            transformers.append((f"cat_{feature}", pipe, [feature]))
        else:
            imp_strat = preprocessing.missing_value_strategies.get(feature, "median")
            const_val = preprocessing.missing_value_constants.get(feature, 0.0)
            scaler_strat = preprocessing.scaling_strategies.get(feature, "none")
            
            pipe = create_numeric_transformer(imp_strat, const_val, scaler_strat)
            transformers.append((f"num_{feature}", pipe, [feature]))

    return ColumnTransformer(transformers=transformers, remainder="drop", verbose_feature_names_out=False)


def create_estimator(model_config: ModelConfig) -> Any:
    """Instantiate scikit-learn regressor based on configuration."""
    if model_config.model_type == "ridge":
        return Ridge(
            alpha=model_config.alpha,
            fit_intercept=model_config.fit_intercept,
            random_state=42
        )
    elif model_config.model_type == "lasso":
        return Lasso(
            alpha=model_config.alpha,
            fit_intercept=model_config.fit_intercept,
            random_state=42,
            max_iter=3000
        )
    else:
        # LinearRegression
        kwargs: Dict[str, Any] = {"fit_intercept": model_config.fit_intercept}
        # Check if 'positive' is supported and requested
        if model_config.positive:
            kwargs["positive"] = True
        return LinearRegression(**kwargs)


def extract_pipeline_coefficients(
    pipeline: Pipeline,
    input_features: List[str],
    inferred_types: Dict[str, str]
) -> Tuple[float, List[CoefficientItem], List[str]]:
    """Extract intercept, mapped coefficients, and transformed feature names."""
    preprocessor: ColumnTransformer = pipeline.named_steps["preprocessor"]
    estimator = pipeline.named_steps["estimator"]

    intercept = float(estimator.intercept_) if getattr(estimator, "fit_intercept", True) else 0.0
    coefs = estimator.coef_
    if hasattr(coefs, "flatten"):
        coefs = coefs.flatten()

    try:
        transformed_names = list(preprocessor.get_feature_names_out())
    except Exception:
        # Fallback if get_feature_names_out fails
        transformed_names = [f"feat_{i}" for i in range(len(coefs))]

    items: List[CoefficientItem] = []
    for i, name in enumerate(transformed_names):
        val = float(coefs[i]) if i < len(coefs) else 0.0
        
        # Determine original feature mapping
        orig_feature = name
        for orig in input_features:
            if name == orig or name.startswith(f"{orig}_"):
                orig_feature = orig
                break

        inf_type = inferred_types.get(orig_feature, "numeric")
        contrib_type = "numeric" if inf_type in ("numeric", "boolean") else "categorical"

        desc = f"A 1-unit increase in {name} is associated with a {val:+.4f} change in the target."
        if abs(val) < 1e-6:
            desc = f"{name} has negligible effect ({val:.2e}) on predictions."

        items.append(
            CoefficientItem(
                feature_name=name,
                original_feature=orig_feature,
                coefficient=round(val, 6),
                contribution_type=contrib_type,
                description=desc,
            )
        )

    # Sort coefficient items by absolute magnitude descending for best pedagogical presentation
    items_sorted = sorted(items, key=lambda x: abs(x.coefficient), reverse=True)

    return round(intercept, 6), items_sorted, transformed_names
