"""Evaluation module calculating regression metrics, diagnostics, chart points, and educational insights."""
import math
from typing import List, Tuple
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from app.schemas.experiment import (
    ChartPoint,
    CoefficientItem,
    MetricSummary,
    ResidualBin,
)

def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> MetricSummary:
    """Compute standard regression metrics safely."""
    if len(y_true) < 2:
        return MetricSummary()

    # Check for NaN / Inf
    mask = np.isfinite(y_true) & np.isfinite(y_pred)
    if mask.sum() < 2:
        return MetricSummary()

    y_t = y_true[mask]
    y_p = y_pred[mask]

    # If variance in y_true is 0, R2 is undefined
    var_y = np.var(y_t)
    r2_val = None
    if var_y > 1e-12:
        r2_val = float(r2_score(y_t, y_p))

    mae_val = float(mean_absolute_error(y_t, y_p))
    mse_val = float(mean_squared_error(y_t, y_p))
    rmse_val = float(math.sqrt(mse_val))

    return MetricSummary(
        r2=round(r2_val, 4) if r2_val is not None else None,
        mae=round(mae_val, 4),
        mse=round(mse_val, 4),
        rmse=round(rmse_val, 4),
    )


def compute_residual_histogram(residuals: np.ndarray, num_bins: int = 14) -> List[ResidualBin]:
    """Compute histogram bins for residual distribution visualization."""
    res_clean = residuals[np.isfinite(residuals)]
    if len(res_clean) == 0:
        return []

    counts, bin_edges = np.histogram(res_clean, bins=num_bins)
    bins: List[ResidualBin] = []
    for i in range(len(counts)):
        bins.append(
            ResidualBin(
                bin_start=round(float(bin_edges[i]), 4),
                bin_end=round(float(bin_edges[i + 1]), 4),
                count=int(counts[i]),
            )
        )
    return bins


def generate_chart_points(
    y_test: np.ndarray,
    y_pred: np.ndarray,
    residuals: np.ndarray,
    max_points: int = 600
) -> List[ChartPoint]:
    """Generate scatter chart points with safe subsampling for responsive rendering."""
    n = len(y_test)
    if n == 0:
        return []

    indices = np.arange(n)
    if n > max_points:
        # Uniform subsample across index order
        step = int(np.ceil(n / max_points))
        indices = indices[::step]

    points: List[ChartPoint] = []
    for idx in indices:
        points.append(
            ChartPoint(
                index=int(idx),
                actual=round(float(y_test[idx]), 4),
                predicted=round(float(y_pred[idx]), 4),
                residual=round(float(residuals[idx]), 4),
            )
        )
    return points


def generate_learning_insights(
    metrics_train: MetricSummary,
    metrics_test: MetricSummary,
    coefficients: List[CoefficientItem],
    residuals: np.ndarray
) -> List[str]:
    """Generate grounded, non-fabricated educational insights for students."""
    insights: List[str] = []

    r2_test = metrics_test.r2
    r2_train = metrics_train.r2
    rmse_test = metrics_test.rmse

    # 1. General model fit
    if r2_test is not None:
        if r2_test > 0.80:
            insights.append(
                f"High explanatory power: The model explains approximately {round(r2_test * 100, 1)}% of variance in the test target."
            )
        elif r2_test > 0.40:
            insights.append(
                f"Moderate explanatory power: The linear model explains {round(r2_test * 100, 1)}% of variance. Some nonlinear dynamics or unobserved variables likely remain."
            )
        elif r2_test >= 0.0:
            insights.append(
                f"Low explanatory power (R² = {r2_test:.3f}): Linear relationships are weak for the chosen features, or key predictors are missing."
            )
        else:
            insights.append(
                f"Negative test R² ({r2_test:.3f}): The model performs worse than simply predicting the training target's mean. This indicates severe overfitting or poor generalization on unseen data."
            )

    # 2. Train vs Test comparison (overfitting vs generalization)
    if r2_train is not None and r2_test is not None:
        diff = r2_train - r2_test
        if diff > 0.15:
            insights.append(
                f"Generalization Gap: Training R² ({r2_train:.3f}) is substantially higher than Test R² ({r2_test:.3f}) by {diff:.3f}. This is a classic indicator of overfitting."
            )
        elif abs(diff) <= 0.05:
            insights.append(
                f"Stable Generalization: Train R² ({r2_train:.3f}) and Test R² ({r2_test:.3f}) are very close, indicating consistent generalization across splits."
            )

    # 3. Key feature drivers
    if coefficients:
        top_feature = coefficients[0]
        insights.append(
            f"Strongest transformed predictor: '{top_feature.feature_name}' with coefficient {top_feature.coefficient:+.4f}."
        )

    # 4. Outliers and Residual distribution
    if rmse_test is not None and len(residuals) > 0:
        large_residuals = np.sum(np.abs(residuals) > 2.5 * rmse_test)
        if large_residuals > 0:
            insights.append(
                f"Outlier alert: {large_residuals} test observations have residuals exceeding 2.5× the RMSE, indicating notable prediction errors on certain edge cases."
            )

    return insights
