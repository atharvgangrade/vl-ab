"""Slope Lab configuration and constants."""
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
STORAGE_DIR = BASE_DIR / "storage"
DATASETS_DIR = STORAGE_DIR / "datasets"
MODELS_DIR = STORAGE_DIR / "models"
EXPERIMENTS_DIR = STORAGE_DIR / "experiments"
SAMPLE_DATASETS_DIR = BASE_DIR / "sample_data"

# Ensure directories exist
for path in [STORAGE_DIR, DATASETS_DIR, MODELS_DIR, EXPERIMENTS_DIR, SAMPLE_DATASETS_DIR]:
    path.mkdir(parents=True, exist_ok=True)

# Dataset limits
MAX_UPLOAD_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB
MAX_ROW_COUNT = 150_000
MAX_PREVIEW_ROWS = 500
SUPPORTED_EXTENSIONS = {".csv", ".xlsx", ".xls", ".json"}
