"""Dataset ingestion, validation, persistence, and retrieval service."""
from datetime import datetime, timezone
import io
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import uuid
import numpy as np
import pandas as pd
from fastapi import HTTPException, UploadFile
from app.config import (
    DATASETS_DIR,
    MAX_ROW_COUNT,
    MAX_UPLOAD_SIZE_BYTES,
    SAMPLE_DATASETS_DIR,
    SUPPORTED_EXTENSIONS,
)
from app.ml.profiler import profile_dataset
from app.schemas.dataset import (
    DatasetPreviewResponse,
    DatasetProfile,
    ManualDatasetCreate,
    SampleDatasetInfo,
)

SAMPLE_CATALOG = [
    SampleDatasetInfo(
        id="sample_real_estate",
        name="Real Estate House Prices",
        description="Predict home sale prices based on living square footage, bedrooms, bathrooms, age, and neighborhood tier.",
        row_count=50,
        feature_count=6,
        suggested_target="Sale_Price",
    ),
    SampleDatasetInfo(
        id="sample_student_exam",
        name="Student Exam Performance",
        description="Predict final course grades from weekly study hours, attendance rate, previous exam scores, sleep, and tutoring enrollment.",
        row_count=40,
        feature_count=5,
        suggested_target="Final_Grade",
    ),
    SampleDatasetInfo(
        id="sample_ad_revenue",
        name="Marketing & Advertising Revenue",
        description="Analyze how TV, radio, and digital advertising spend across different sales regions impact sales revenue.",
        row_count=40,
        feature_count=4,
        suggested_target="Sales_Revenue",
    ),
]


class DatasetService:
    def __init__(self):
        self._profiles_cache: Dict[str, DatasetProfile] = {}

    def _get_dataset_path(self, dataset_id: str) -> Path:
        return DATASETS_DIR / f"{dataset_id}.pkl"

    def _clean_and_validate_df(self, df: pd.DataFrame, source_name: str) -> pd.DataFrame:
        if df.empty or len(df.columns) == 0:
            raise HTTPException(status_code=400, detail="The dataset is empty and contains no usable rows or columns.")

        # Check row limits
        if len(df) > MAX_ROW_COUNT:
            raise HTTPException(
                status_code=400,
                detail=f"Dataset exceeds the maximum supported row count of {MAX_ROW_COUNT:,} (found {len(df):,} rows)."
            )

        # Clean column headers
        clean_cols = []
        seen = {}
        for i, col in enumerate(df.columns):
            c_str = str(col).strip()
            if not c_str or c_str.lower() in ("unnamed: 0", "none", "nan"):
                c_str = f"feature_{i + 1}"
            
            # Deduplicate column names
            if c_str in seen:
                seen[c_str] += 1
                c_str = f"{c_str}_{seen[c_str]}"
            else:
                seen[c_str] = 0
            clean_cols.append(c_str)

        df.columns = clean_cols

        # Ensure all columns have string names
        df.columns = [str(c) for c in df.columns]

        # Check usable observations
        if len(df) < 5:
            raise HTTPException(
                status_code=400,
                detail=f"Dataset has only {len(df)} rows. At least 5 observations are required for model training and evaluation."
            )

        return df

    def parse_file(self, filename: str, content: bytes) -> Tuple[pd.DataFrame, str]:
        ext = Path(filename).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            supported_str = ", ".join(sorted(list(SUPPORTED_EXTENSIONS)))
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file format '{ext}'. Supported formats are: {supported_str}."
            )

        if len(content) == 0:
            raise HTTPException(status_code=400, detail="Uploaded file is empty (0 bytes).")

        if len(content) > MAX_UPLOAD_SIZE_BYTES:
            max_mb = MAX_UPLOAD_SIZE_BYTES // (1024 * 1024)
            raise HTTPException(status_code=400, detail=f"File exceeds maximum upload size of {max_mb} MB.")

        try:
            if ext == ".csv":
                try:
                    df = pd.read_csv(io.BytesIO(content), encoding="utf-8")
                except UnicodeDecodeError:
                    df = pd.read_csv(io.BytesIO(content), encoding="latin1")
            elif ext in (".xlsx", ".xls"):
                df = pd.read_excel(io.BytesIO(content))
            elif ext == ".json":
                try:
                    raw_json = json.loads(content.decode("utf-8"))
                    if isinstance(raw_json, list):
                        df = pd.DataFrame(raw_json)
                    elif isinstance(raw_json, dict):
                        # Attempt common tabular JSON representations
                        if "data" in raw_json and isinstance(raw_json["data"], list):
                            df = pd.DataFrame(raw_json["data"])
                        elif "records" in raw_json and isinstance(raw_json["records"], list):
                            df = pd.DataFrame(raw_json["records"])
                        else:
                            df = pd.DataFrame.from_dict(raw_json)
                    else:
                        raise ValueError("JSON must contain an array of records or a dictionary of tabular data.")
                except Exception as json_err:
                    raise HTTPException(status_code=400, detail=f"Invalid JSON format: {str(json_err)}")
            else:
                raise HTTPException(status_code=400, detail=f"Unhandled format {ext}")
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to parse file: {str(e)}")

        return df, ext[1:].upper()

    def save_dataframe(self, df: pd.DataFrame, dataset_id: str, name: str, fmt: str) -> DatasetProfile:
        path = self._get_dataset_path(dataset_id)
        # Store as pickle for zero-dependency native pandas schema retention
        df.to_pickle(path)

        created_at = datetime.now(timezone.utc).isoformat()
        profile = profile_dataset(df, dataset_id, name, fmt, created_at)
        self._profiles_cache[dataset_id] = profile
        return profile

    def load_dataframe(self, dataset_id: str) -> pd.DataFrame:
        path = self._get_dataset_path(dataset_id)
        if not path.exists():
            # Check if it is a sample dataset
            if dataset_id == "sample_real_estate":
                return self.load_sample("sample_real_estate")
            elif dataset_id == "sample_student_exam":
                return self.load_sample("sample_student_exam")
            elif dataset_id == "sample_ad_revenue":
                return self.load_sample("sample_ad_revenue")
            raise HTTPException(status_code=404, detail=f"Dataset '{dataset_id}' not found.")
        return pd.read_pickle(path)

    def upload_dataset(self, file: UploadFile) -> DatasetProfile:
        contents = file.file.read()
        df, fmt = self.parse_file(file.filename or "dataset", contents)
        df = self._clean_and_validate_df(df, file.filename or "uploaded_dataset")

        dataset_id = uuid.uuid4().hex[:12]
        display_name = Path(file.filename or "Dataset").stem
        return self.save_dataframe(df, dataset_id, display_name, fmt)

    def create_manual_dataset(self, data: ManualDatasetCreate) -> DatasetProfile:
        if not data.columns or len(data.columns) == 0:
            raise HTTPException(status_code=400, detail="At least one column name must be provided.")
        
        if not data.rows or len(data.rows) == 0:
            raise HTTPException(status_code=400, detail="At least one row of data is required.")

        df = pd.DataFrame(data.rows)
        # Reorder / filter to explicitly specified columns
        for c in data.columns:
            if c not in df.columns:
                df[c] = np.nan
        df = df[data.columns]

        # Apply user requested data types if specified
        if data.column_types:
            for col, col_type in data.column_types.items():
                if col in df.columns:
                    if col_type == "numeric":
                        df[col] = pd.to_numeric(df[col], errors="coerce")
                    elif col_type == "categorical":
                        df[col] = df[col].astype(str)

        df = self._clean_and_validate_df(df, data.name)
        dataset_id = uuid.uuid4().hex[:12]
        return self.save_dataframe(df, dataset_id, data.name, "MANUAL")

    def load_sample(self, sample_id: str) -> pd.DataFrame:
        mapping = {
            "sample_real_estate": ("real_estate.csv", "Real Estate House Prices"),
            "sample_student_exam": ("student_exam.csv", "Student Exam Performance"),
            "sample_ad_revenue": ("ad_revenue.csv", "Marketing & Advertising Revenue"),
        }
        if sample_id not in mapping:
            raise HTTPException(status_code=404, detail=f"Sample dataset '{sample_id}' not found.")
        
        filename, name = mapping[sample_id]
        csv_path = SAMPLE_DATASETS_DIR / filename
        if not csv_path.exists():
            raise HTTPException(status_code=404, detail=f"Sample file {filename} is missing.")
        
        df = pd.read_csv(csv_path)
        df = self._clean_and_validate_df(df, name)
        # Persist as active dataset
        self.save_dataframe(df, sample_id, name, "CSV")
        return df

    def get_profile(self, dataset_id: str) -> DatasetProfile:
        if dataset_id in self._profiles_cache:
            return self._profiles_cache[dataset_id]
        
        df = self.load_dataframe(dataset_id)
        name = dataset_id
        for s in SAMPLE_CATALOG:
            if s.id == dataset_id:
                name = s.name
        profile = profile_dataset(
            df,
            dataset_id,
            name,
            "PARQUET",
            datetime.now(timezone.utc).isoformat()
        )
        self._profiles_cache[dataset_id] = profile
        return profile

    def get_preview(self, dataset_id: str, page: int = 1, page_size: int = 25) -> DatasetPreviewResponse:
        df = self.load_dataframe(dataset_id)
        total_rows = len(df)
        page_size = max(5, min(page_size, 100))
        total_pages = max(1, int(np.ceil(total_rows / page_size)))
        page = max(1, min(page, total_pages))

        start_idx = (page - 1) * page_size
        end_idx = min(start_idx + page_size, total_rows)

        page_df = df.iloc[start_idx:end_idx].copy()
        
        # Convert NaN / Inf to None for JSON serialization
        page_df = page_df.replace([np.inf, -np.inf], None)
        page_df = page_df.where(pd.notnull(page_df), None)

        rows = page_df.to_dict(orient="records")

        return DatasetPreviewResponse(
            dataset_id=dataset_id,
            columns=list(df.columns),
            rows=rows,
            total_rows=total_rows,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
        )

    def delete_dataset(self, dataset_id: str) -> bool:
        path = self._get_dataset_path(dataset_id)
        if path.exists():
            path.unlink()
        self._profiles_cache.pop(dataset_id, None)
        return True

dataset_service = DatasetService()
