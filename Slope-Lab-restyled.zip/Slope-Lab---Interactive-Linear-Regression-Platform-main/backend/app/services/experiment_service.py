"""Experiment orchestration service for model training, evaluation, persistence, and prediction."""
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
import uuid
import joblib
import numpy as np
import pandas as pd
from fastapi import HTTPException
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from app.config import EXPERIMENTS_DIR, MODELS_DIR
from app.ml.evaluator import (
    compute_metrics,
    compute_residual_histogram,
    generate_chart_points,
    generate_learning_insights,
)
from app.ml.pipeline_builder import (
    build_preprocessor,
    create_estimator,
    extract_pipeline_coefficients,
)
from app.schemas.experiment import (
    ExperimentCreate,
    ExperimentResult,
    FeatureContribution,
    PredictRequest,
    PredictResponse,
    ValidationResponse,
)
from app.services.dataset_service import dataset_service

class ExperimentService:
    def __init__(self):
        self._results_cache: Dict[str, ExperimentResult] = {}

    def _get_model_path(self, experiment_id: str) -> Path:
        return MODELS_DIR / f"{experiment_id}.joblib"

    def _get_meta_path(self, experiment_id: str) -> Path:
        return EXPERIMENTS_DIR / f"{experiment_id}.json"

    def validate_configuration(self, config: ExperimentCreate) -> ValidationResponse:
        errors: List[str] = []
        warnings: List[str] = []

        try:
            df = dataset_service.load_dataframe(config.dataset_id)
        except HTTPException as e:
            return ValidationResponse(valid=False, errors=[e.detail])

        # Validate target
        if not config.target_feature:
            errors.append("A target feature (y) must be selected.")
        elif config.target_feature not in df.columns:
            errors.append(f"Target column '{config.target_feature}' does not exist in the dataset.")
        else:
            target_series = df[config.target_feature]
            num_target = pd.to_numeric(target_series, errors="coerce")
            valid_target_count = int(num_target.notna().sum())
            if valid_target_count < 10:
                errors.append(
                    f"Target column '{config.target_feature}' has only {valid_target_count} valid numeric values. At least 10 are required for regression."
                )

        # Validate input features
        if not config.input_features:
            errors.append("At least one input feature (X) must be selected.")
        else:
            missing_features = [f for f in config.input_features if f not in df.columns]
            if missing_features:
                errors.append(f"Features {missing_features} do not exist in the dataset.")

            if config.target_feature in config.input_features:
                errors.append(f"Target feature '{config.target_feature}' cannot also be included as an input feature.")

            # Target leakage / Identifier checks
            for feat in config.input_features:
                col_lower = feat.lower()
                if any(k in col_lower for k in ["id", "uuid", "identifier"]):
                    warnings.append(f"Feature '{feat}' appears to be an identifier. It may introduce spurious correlations.")
                if feat in df.columns and df[feat].nunique() == len(df) and df[feat].nunique() > 20:
                    warnings.append(f"Feature '{feat}' has 100% unique values (potential ID).")

        # Validate split
        total_rows = len(df)
        test_size = config.split.test_size
        est_test = int(np.round(total_rows * test_size))
        est_train = total_rows - est_test

        if est_test < 5:
            errors.append(f"Test split ({est_test} rows) is too small. Increase test size or use a larger dataset.")
        if est_train < 8:
            errors.append(f"Train split ({est_train} rows) is too small. Decrease test size or use a larger dataset.")

        is_valid = len(errors) == 0
        return ValidationResponse(
            valid=is_valid,
            errors=errors,
            warnings=warnings,
            estimated_train_rows=est_train if is_valid else None,
            estimated_test_rows=est_test if is_valid else None,
            estimated_features_out=len(config.input_features) if is_valid else None,
        )

    def train_experiment(self, config: ExperimentCreate) -> ExperimentResult:
        # 1. Validate
        val = self.validate_configuration(config)
        if not val.valid:
            raise HTTPException(status_code=400, detail="; ".join(val.errors))

        df = dataset_service.load_dataframe(config.dataset_id).copy()
        profile = dataset_service.get_profile(config.dataset_id)
        inferred_types = {col.name: col.inferred_type for col in profile.columns}

        # 2. Extract X and y
        y_raw = pd.to_numeric(df[config.target_feature], errors="coerce")
        # Handle missing target
        valid_mask = y_raw.notna() & np.isfinite(y_raw)
        df_clean = df.loc[valid_mask].copy()
        y_clean = y_raw.loc[valid_mask].values

        if len(df_clean) < 10:
            raise HTTPException(
                status_code=400,
                detail=f"Only {len(df_clean)} observations remain after dropping missing target values."
            )

        X_df = df_clean[config.input_features].copy()

        # 3. Train-Test Split (BEFORE any fitting to prevent data leakage)
        split_cfg = config.split
        if split_cfg.split_mode == "chronological":
            # Chronological split without shuffling
            test_count = int(np.round(len(df_clean) * split_cfg.test_size))
            train_count = len(df_clean) - test_count
            X_train, X_test = X_df.iloc[:train_count], X_df.iloc[train_count:]
            y_train, y_test = y_clean[:train_count], y_clean[train_count:]
        else:
            # Shuffled split
            X_train, X_test, y_train, y_test = train_test_split(
                X_df,
                y_clean,
                test_size=split_cfg.test_size,
                random_state=split_cfg.random_state,
                shuffle=split_cfg.shuffle,
            )

        # 4. Optional duplicate removal on training set
        if config.preprocessing.remove_duplicate_rows:
            train_dups = X_train.duplicated()
            X_train = X_train.loc[~train_dups]
            y_train = y_train[~train_dups.values]

        # 5. Build Pipeline: Preprocessor + Estimator
        preprocessor = build_preprocessor(
            df_sample=X_train,
            input_features=config.input_features,
            preprocessing=config.preprocessing,
            inferred_types=inferred_types,
        )
        estimator = create_estimator(config.model)

        pipeline = Pipeline(steps=[
            ("preprocessor", preprocessor),
            ("estimator", estimator),
        ])

        # 6. Fit Pipeline strictly on training data
        try:
            pipeline.fit(X_train, y_train)
        except Exception as fit_err:
            raise HTTPException(
                status_code=400,
                detail=f"Model training failed during pipeline fitting: {str(fit_err)}"
            )

        # 7. Evaluate on both Test and Train sets
        y_pred_test = pipeline.predict(X_test)
        y_pred_train = pipeline.predict(X_train)

        metrics_test = compute_metrics(y_test, y_pred_test)
        metrics_train = compute_metrics(y_train, y_pred_train)

        # Residuals on test
        residuals_test = y_test - y_pred_test

        # 8. Extract coefficients & transformed features
        intercept, coefficients, transformed_names = extract_pipeline_coefficients(
            pipeline=pipeline,
            input_features=config.input_features,
            inferred_types=inferred_types,
        )

        # 9. Diagnostics & visual points
        scatter_points = generate_chart_points(y_test, y_pred_test, residuals_test, max_points=600)
        residual_bins = compute_residual_histogram(residuals_test, num_bins=12)
        insights = generate_learning_insights(metrics_train, metrics_test, coefficients, residuals_test)

        experiment_id = uuid.uuid4().hex[:12]
        created_at = datetime.now(timezone.utc).isoformat()

        result = ExperimentResult(
            experiment_id=experiment_id,
            dataset_id=config.dataset_id,
            name=config.name,
            created_at=created_at,
            config=config,
            train_rows=len(X_train),
            test_rows=len(X_test),
            total_features_in=len(config.input_features),
            total_features_out=len(transformed_names),
            transformed_feature_names=transformed_names,
            intercept=intercept,
            coefficients=coefficients,
            metrics_test=metrics_test,
            metrics_train=metrics_train,
            scatter_data=scatter_points,
            residual_histogram=residual_bins,
            learning_insights=insights,
            warnings=val.warnings,
        )

        # 10. Persist pipeline and result locally
        model_path = self._get_model_path(experiment_id)
        joblib.dump(pipeline, model_path)

        meta_path = self._get_meta_path(experiment_id)
        with open(meta_path, "w", encoding="utf-8") as f:
            f.write(result.model_dump_json(indent=2))

        self._results_cache[experiment_id] = result
        return result

    def get_experiment(self, experiment_id: str) -> ExperimentResult:
        if experiment_id in self._results_cache:
            return self._results_cache[experiment_id]

        meta_path = self._get_meta_path(experiment_id)
        if not meta_path.exists():
            raise HTTPException(status_code=404, detail=f"Experiment '{experiment_id}' not found.")

        with open(meta_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            result = ExperimentResult.model_validate(data)
            self._results_cache[experiment_id] = result
            return result

    def list_experiments(self) -> List[Dict[str, Any]]:
        exps = []
        for file in sorted(EXPERIMENTS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    exps.append({
                        "experiment_id": data.get("experiment_id"),
                        "name": data.get("name"),
                        "dataset_id": data.get("dataset_id"),
                        "created_at": data.get("created_at"),
                        "r2_test": data.get("metrics_test", {}).get("r2"),
                        "rmse_test": data.get("metrics_test", {}).get("rmse"),
                        "model_type": data.get("config", {}).get("model", {}).get("model_type"),
                    })
            except Exception:
                continue
        return exps

    def predict(self, experiment_id: str, request: PredictRequest) -> PredictResponse:
        model_path = self._get_model_path(experiment_id)
        if not model_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Trained model for experiment '{experiment_id}' not found. Please train the model first."
            )

        pipeline: Pipeline = joblib.load(model_path)
        experiment = self.get_experiment(experiment_id)

        # Prepare single row DataFrame
        input_data = {}
        for feature in experiment.config.input_features:
            val = request.inputs.get(feature)
            input_data[feature] = [val]

        df_input = pd.DataFrame(input_data)

        try:
            # 1. Overall prediction from pipeline
            raw_pred = pipeline.predict(df_input)
            prediction_val = float(raw_pred[0])
        except Exception as pred_err:
            raise HTTPException(
                status_code=400,
                detail=f"Prediction failed on supplied inputs: {str(pred_err)}"
            )

        # 2. Extract feature-level contributions
        preprocessor = pipeline.named_steps["preprocessor"]
        estimator = pipeline.named_steps["estimator"]
        intercept = float(estimator.intercept_) if getattr(estimator, "fit_intercept", True) else 0.0

        coefs = estimator.coef_
        if hasattr(coefs, "flatten"):
            coefs = coefs.flatten()

        try:
            transformed_row = preprocessor.transform(df_input)
            if hasattr(transformed_row, "toarray"):
                transformed_row = transformed_row.toarray()
            transformed_row = transformed_row.flatten()
        except Exception:
            transformed_row = np.zeros(len(coefs))

        transformed_names = experiment.transformed_feature_names

        contributions: List[FeatureContribution] = []
        formula_terms = [f"{intercept:+.3f}"]

        for i, name in enumerate(transformed_names):
            c_val = float(coefs[i]) if i < len(coefs) else 0.0
            t_val = float(transformed_row[i]) if i < len(transformed_row) else 0.0
            contrib = c_val * t_val

            # Map to original feature
            orig_feature = name
            for orig in experiment.config.input_features:
                if name == orig or name.startswith(f"{orig}_"):
                    orig_feature = orig
                    break

            raw_val = request.inputs.get(orig_feature)

            contributions.append(
                FeatureContribution(
                    feature_name=name,
                    original_feature=orig_feature,
                    raw_value=raw_val,
                    transformed_value=round(t_val, 4),
                    coefficient=round(c_val, 4),
                    contribution=round(contrib, 4),
                )
            )

            if abs(c_val) > 1e-5 and abs(t_val) > 1e-5:
                formula_terms.append(f"({c_val:+.2f} × {t_val:.2f})")

        formula = f"ŷ = " + " + ".join(formula_terms)

        return PredictResponse(
            experiment_id=experiment_id,
            prediction=round(prediction_val, 4),
            intercept=round(intercept, 4),
            contributions=contributions,
            raw_inputs=request.inputs,
            equation_formula=formula,
        )

experiment_service = ExperimentService()
