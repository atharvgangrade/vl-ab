"""Pydantic schemas for experiments, training, metrics, and predictions."""
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class PreprocessingConfig(BaseModel):
    # Strategy per column: 'mean', 'median', 'constant', 'drop_row', 'none', 'most_frequent'
    missing_value_strategies: Dict[str, str] = Field(default_factory=dict)
    missing_value_constants: Dict[str, Any] = Field(default_factory=dict)
    missing_target_strategy: str = "drop_row"  # 'drop_row' or 'error'
    
    # Scaling per column: 'none', 'standard', 'minmax', 'robust', 'maxabs'
    scaling_strategies: Dict[str, str] = Field(default_factory=dict)
    
    # Encoding per column: 'none', 'onehot', 'ordinal'
    encoding_strategies: Dict[str, str] = Field(default_factory=dict)
    ordinal_orders: Dict[str, List[str]] = Field(default_factory=dict)
    handle_unknown_categorical: str = "ignore"  # 'ignore' or 'error'
    
    remove_duplicate_rows: bool = False
    remove_constant_features: bool = True

class SplitConfig(BaseModel):
    test_size: float = Field(default=0.2, ge=0.05, le=0.5)
    random_state: Optional[int] = 42
    shuffle: bool = True
    split_mode: str = "random"  # 'random' or 'chronological'

class ModelConfig(BaseModel):
    model_type: str = "linear_regression"  # 'linear_regression', 'ridge', 'lasso'
    fit_intercept: bool = True
    positive: bool = False
    alpha: float = Field(default=1.0, ge=0.0001, le=10000.0)

class ExperimentCreate(BaseModel):
    dataset_id: str
    name: str = "Linear Regression Experiment"
    input_features: List[str]
    target_feature: str
    preprocessing: PreprocessingConfig = Field(default_factory=PreprocessingConfig)
    split: SplitConfig = Field(default_factory=SplitConfig)
    model: ModelConfig = Field(default_factory=ModelConfig)

class ValidationResponse(BaseModel):
    valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    estimated_train_rows: Optional[int] = None
    estimated_test_rows: Optional[int] = None
    estimated_features_out: Optional[int] = None

class MetricSummary(BaseModel):
    r2: Optional[float] = None
    mae: Optional[float] = None
    mse: Optional[float] = None
    rmse: Optional[float] = None

class CoefficientItem(BaseModel):
    feature_name: str
    original_feature: str
    coefficient: float
    contribution_type: str  # 'intercept', 'numeric', 'categorical'
    description: str

class ChartPoint(BaseModel):
    index: int
    actual: float
    predicted: float
    residual: float

class ResidualBin(BaseModel):
    bin_start: float
    bin_end: float
    count: int

class ExperimentResult(BaseModel):
    experiment_id: str
    dataset_id: str
    name: str
    created_at: str
    config: ExperimentCreate
    train_rows: int
    test_rows: int
    total_features_in: int
    total_features_out: int
    transformed_feature_names: List[str]
    intercept: float
    coefficients: List[CoefficientItem]
    metrics_test: MetricSummary
    metrics_train: MetricSummary
    scatter_data: List[ChartPoint]
    residual_histogram: List[ResidualBin]
    learning_insights: List[str]
    warnings: List[str] = Field(default_factory=list)

class FeatureContribution(BaseModel):
    feature_name: str
    original_feature: str
    raw_value: Any
    transformed_value: Optional[float] = None
    coefficient: float
    contribution: float  # coefficient * transformed_value

class PredictRequest(BaseModel):
    inputs: Dict[str, Any]

class PredictResponse(BaseModel):
    experiment_id: str
    prediction: float
    intercept: float
    contributions: List[FeatureContribution]
    raw_inputs: Dict[str, Any]
    equation_formula: str
