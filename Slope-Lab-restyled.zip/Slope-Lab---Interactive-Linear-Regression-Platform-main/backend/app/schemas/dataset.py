"""Pydantic schemas for dataset operations and profiling."""
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class NumericStats(BaseModel):
    min: float
    max: float
    mean: float
    median: float
    std: float
    q25: float
    q75: float

class CategoryFrequency(BaseModel):
    value: str
    count: int
    percentage: float

class ColumnProfile(BaseModel):
    name: str
    dtype: str
    inferred_type: str  # 'numeric', 'categorical', 'boolean', 'datetime', 'identifier'
    missing_count: int
    missing_percentage: float
    unique_count: int
    unique_percentage: float
    sample_values: List[Any]
    numeric_stats: Optional[NumericStats] = None
    top_categories: Optional[List[CategoryFrequency]] = None
    issues: List[str] = Field(default_factory=list)

class DatasetProfile(BaseModel):
    id: str
    name: str
    format: str
    row_count: int
    column_count: int
    duplicate_row_count: int
    has_missing_values: bool
    columns: List[ColumnProfile]
    created_at: str

class DatasetPreviewResponse(BaseModel):
    dataset_id: str
    columns: List[str]
    rows: List[Dict[str, Any]]
    total_rows: int
    page: int
    page_size: int
    total_pages: int

class ManualDatasetCreate(BaseModel):
    name: str = "Manual Dataset"
    columns: List[str]
    rows: List[Dict[str, Any]]
    column_types: Optional[Dict[str, str]] = None

class SampleDatasetInfo(BaseModel):
    id: str
    name: str
    description: str
    row_count: int
    feature_count: int
    suggested_target: str
