"""Comprehensive automated tests for Slope Lab backend."""
import io
import json
import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.ml.evaluator import compute_metrics
from app.ml.pipeline_builder import build_preprocessor, create_estimator
from app.ml.profiler import profile_dataset
from app.schemas.experiment import (
    ExperimentCreate,
    ModelConfig,
    PredictRequest,
    PreprocessingConfig,
    SplitConfig,
)
from app.services.dataset_service import dataset_service
from app.services.experiment_service import experiment_service

client = TestClient(app)

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_sample_datasets_catalog():
    response = client.get("/api/datasets/samples")
    assert response.status_code == 200
    samples = response.json()
    assert len(samples) >= 3
    ids = [s["id"] for s in samples]
    assert "sample_real_estate" in ids


def test_load_sample_dataset():
    response = client.post("/api/datasets/samples/sample_real_estate/load")
    assert response.status_code == 200
    data = response.json()
    assert data["id"] == "sample_real_estate"
    assert data["row_count"] == 50
    assert data["column_count"] == 7
    # Check columns
    col_names = [c["name"] for c in data["columns"]]
    assert "Square_Feet" in col_names
    assert "Sale_Price" in col_names


def test_dataset_preview():
    response = client.get("/api/datasets/sample_real_estate/preview?page=1&page_size=10")
    assert response.status_code == 200
    preview = response.json()
    assert preview["total_rows"] == 50
    assert len(preview["rows"]) == 10
    assert preview["total_pages"] == 5


def test_manual_dataset_creation():
    payload = {
        "name": "Manual Lab Test",
        "columns": ["x1", "x2", "category", "target"],
        "rows": [
            {"x1": 1.0, "x2": 10.0, "category": "A", "target": 12.0},
            {"x1": 2.0, "x2": 20.0, "category": "B", "target": 22.0},
            {"x1": 3.0, "x2": 30.0, "category": "A", "target": 32.0},
            {"x1": 4.0, "x2": 40.0, "category": "B", "target": 42.0},
            {"x1": 5.0, "x2": 50.0, "category": "A", "target": 52.0},
            {"x1": 6.0, "x2": 60.0, "category": "B", "target": 62.0},
            {"x1": 7.0, "x2": 70.0, "category": "A", "target": 72.0},
            {"x1": 8.0, "x2": 80.0, "category": "B", "target": 82.0},
            {"x1": 9.0, "x2": 90.0, "category": "A", "target": 92.0},
            {"x1": 10.0, "x2": 100.0, "category": "B", "target": 102.0},
            {"x1": 11.0, "x2": 110.0, "category": "A", "target": 112.0},
            {"x1": 12.0, "x2": 120.0, "category": "B", "target": 122.0},
        ],
    }
    response = client.post("/api/datasets/manual", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["row_count"] == 12
    assert data["column_count"] == 4


def test_upload_invalid_file_extension():
    fake_file = io.BytesIO(b"malicious or invalid code")
    response = client.post(
        "/api/datasets/upload",
        files={"file": ("test.exe", fake_file, "application/octet-stream")},
    )
    assert response.status_code == 400
    assert "Unsupported file format" in response.json()["detail"]


def test_upload_empty_csv():
    empty_file = io.BytesIO(b"")
    response = client.post(
        "/api/datasets/upload",
        files={"file": ("empty.csv", empty_file, "text/csv")},
    )
    assert response.status_code == 400
    assert "empty" in response.json()["detail"].lower()


def test_experiment_validation_and_training():
    # Load sample first
    client.post("/api/datasets/samples/sample_real_estate/load")

    exp_config = {
        "dataset_id": "sample_real_estate",
        "name": "House Price Linear Regression",
        "input_features": ["Square_Feet", "Bedrooms", "Bathrooms", "Age_Years", "Neighborhood_Tier"],
        "target_feature": "Sale_Price",
        "preprocessing": {
            "missing_value_strategies": {
                "Square_Feet": "median",
                "Neighborhood_Tier": "most_frequent",
            },
            "scaling_strategies": {
                "Square_Feet": "standard",
                "Bedrooms": "minmax",
                "Bathrooms": "none",
                "Age_Years": "standard",
            },
            "encoding_strategies": {
                "Neighborhood_Tier": "onehot",
            },
            "handle_unknown_categorical": "ignore",
            "remove_duplicate_rows": False,
        },
        "split": {
            "test_size": 0.2,
            "random_state": 42,
            "shuffle": True,
            "split_mode": "random",
        },
        "model": {
            "model_type": "linear_regression",
            "fit_intercept": True,
            "positive": False,
        },
    }

    # 1. Test validation endpoint
    val_resp = client.post("/api/experiments/validate", json=exp_config)
    assert val_resp.status_code == 200
    assert val_resp.json()["valid"] is True

    # 2. Test train endpoint
    train_resp = client.post("/api/experiments/train", json=exp_config)
    assert train_resp.status_code == 200
    result = train_resp.json()

    assert result["train_rows"] == 40
    assert result["test_rows"] == 10
    assert result["metrics_test"]["r2"] is not None
    assert result["metrics_test"]["mae"] is not None
    assert result["metrics_test"]["rmse"] is not None
    assert len(result["coefficients"]) > 0
    assert len(result["scatter_data"]) == 10
    assert len(result["residual_histogram"]) > 0
    assert len(result["learning_insights"]) > 0

    exp_id = result["experiment_id"]

    # 3. Test prediction endpoint using fitted pipeline
    pred_payload = {
        "inputs": {
            "Square_Feet": 2000,
            "Bedrooms": 3,
            "Bathrooms": 2.0,
            "Age_Years": 10,
            "Neighborhood_Tier": "Urban",
        }
    }
    pred_resp = client.post(f"/api/experiments/{exp_id}/predict", json=pred_payload)
    assert pred_resp.status_code == 200
    pred_data = pred_resp.json()
    assert pred_data["prediction"] > 100000
    assert len(pred_data["contributions"]) > 0
    assert "ŷ = " in pred_data["equation_formula"]


def test_ridge_and_lasso_training():
    for m_type in ["ridge", "lasso"]:
        exp_config = {
            "dataset_id": "sample_student_exam",
            "name": f"{m_type.capitalize()} Student Model",
            "input_features": ["Study_Hours", "Attendance_Percent", "Tutoring_Enrolled"],
            "target_feature": "Final_Grade",
            "preprocessing": {
                "scaling_strategies": {
                    "Study_Hours": "standard",
                    "Attendance_Percent": "standard",
                },
                "encoding_strategies": {
                    "Tutoring_Enrolled": "onehot",
                },
            },
            "split": {"test_size": 0.25, "random_state": 42},
            "model": {
                "model_type": m_type,
                "fit_intercept": True,
                "alpha": 1.5,
            },
        }
        resp = client.post("/api/experiments/train", json=exp_config)
        assert resp.status_code == 200
        assert resp.json()["config"]["model"]["model_type"] == m_type
        assert resp.json()["metrics_test"]["r2"] is not None


def test_invalid_target_rejection():
    # Invalid target: non-existent or same as input
    bad_config = {
        "dataset_id": "sample_real_estate",
        "name": "Invalid Target Test",
        "input_features": ["Square_Feet", "Sale_Price"],
        "target_feature": "Sale_Price",
        "split": {"test_size": 0.2},
    }
    resp = client.post("/api/experiments/validate", json=bad_config)
    assert resp.status_code == 200
    assert resp.json()["valid"] is False
    assert any("cannot also be included" in err for err in resp.json()["errors"])


def test_no_data_leakage_in_scaling():
    """Verify that preprocessing scalers are fitted ONLY on training split."""
    # Create dataset with clear difference between first rows (train) and last rows (test)
    rows = []
    for i in range(20):
        rows.append({"feature_x": float(i), "target": float(i * 2 + 5)})
    # Test rows have huge values
    for i in range(5):
        rows.append({"feature_x": float(1000 + i * 10), "target": float(2000 + i * 20)})

    manual_data = {
        "name": "Leakage Test Dataset",
        "columns": ["feature_x", "target"],
        "rows": rows,
    }
    ds_resp = client.post("/api/datasets/manual", json=manual_data)
    ds_id = ds_resp.json()["id"]

    # Use chronological split so training split is strictly the first 20 rows (0..19), test is last 5 rows
    config = {
        "dataset_id": ds_id,
        "name": "Leakage Test Run",
        "input_features": ["feature_x"],
        "target_feature": "target",
        "preprocessing": {
            "scaling_strategies": {"feature_x": "standard"},
        },
        "split": {
            "test_size": 0.2,
            "split_mode": "chronological",
            "shuffle": False,
        },
        "model": {"model_type": "linear_regression"},
    }
    train_resp = client.post("/api/experiments/train", json=config)
    assert train_resp.status_code == 200
    res = train_resp.json()
    assert res["train_rows"] == 20
    assert res["test_rows"] == 5

    # Check fitted model path
    exp_id = res["experiment_id"]
    import joblib
    from app.config import MODELS_DIR
    pipeline = joblib.load(MODELS_DIR / f"{exp_id}.joblib")
    preproc = pipeline.named_steps["preprocessor"]
    scaler = preproc.named_transformers_["num_feature_x"].named_steps["scaler"]

    # The mean of 0..19 is exactly 9.5. The mean of the whole dataset with 1000+ would be > 200.
    fitted_mean = float(scaler.mean_[0])
    assert abs(fitted_mean - 9.5) < 1e-4, f"Fitted mean was {fitted_mean}, expected 9.5 (no leakage)!"


def test_unknown_category_in_prediction():
    """Verify that predictions with previously unseen categories do not crash."""
    config = {
        "dataset_id": "sample_real_estate",
        "name": "Unknown Category Test",
        "input_features": ["Square_Feet", "Neighborhood_Tier"],
        "target_feature": "Sale_Price",
        "preprocessing": {
            "encoding_strategies": {"Neighborhood_Tier": "onehot"},
            "handle_unknown_categorical": "ignore",
        },
        "split": {"test_size": 0.2, "random_state": 42},
        "model": {"model_type": "linear_regression"},
    }
    train_resp = client.post("/api/experiments/train", json=config)
    assert train_resp.status_code == 200
    exp_id = train_resp.json()["experiment_id"]

    # Submit an unseen neighborhood category "OuterSpace"
    pred_resp = client.post(
        f"/api/experiments/{exp_id}/predict",
        json={"inputs": {"Square_Feet": 1500, "Neighborhood_Tier": "OuterSpace"}},
    )
    assert pred_resp.status_code == 200
    assert pred_resp.json()["prediction"] is not None

