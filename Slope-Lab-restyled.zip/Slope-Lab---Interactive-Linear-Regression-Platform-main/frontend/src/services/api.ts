import {
  DatasetPreviewResponse,
  DatasetProfile,
  ExperimentCreate,
  ExperimentHistoryItem,
  ExperimentResult,
  PredictResponse,
  SampleDatasetInfo,
  ValidationResponse,
} from '../types';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000';

class ApiService {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const url = `${API_BASE}${endpoint}`;
    try {
      const res = await fetch(url, options);
      if (!res.ok) {
        let errorDetail = `Request failed with status ${res.status}`;
        try {
          const errJson = await res.json();
          if (errJson && errJson.detail) {
            errorDetail = errJson.detail;
          }
        } catch {
          // keep fallback error message
        }
        throw new Error(errorDetail);
      }
      return await res.json();
    } catch (err: any) {
      if (err.message === 'Failed to fetch' || err.name === 'TypeError') {
        throw new Error(`Unable to connect to the Slope Lab backend (${API_BASE}). Ensure the Python server is running.`);
      }
      throw err;
    }
  }

  async getHealth(): Promise<{ status: string }> {
    return this.request<{ status: string }>('/api/health');
  }

  async getSamples(): Promise<SampleDatasetInfo[]> {
    return this.request<SampleDatasetInfo[]>('/api/datasets/samples');
  }

  async loadSample(sampleId: string): Promise<DatasetProfile> {
    return this.request<DatasetProfile>(`/api/datasets/samples/${sampleId}/load`, {
      method: 'POST',
    });
  }

  async uploadDataset(file: File): Promise<DatasetProfile> {
    const formData = new FormData();
    formData.append('file', file);
    return this.request<DatasetProfile>('/api/datasets/upload', {
      method: 'POST',
      body: formData,
    });
  }

  async createManualDataset(data: {
    name: string;
    columns: string[];
    rows: Record<string, any>[];
  }): Promise<DatasetProfile> {
    return this.request<DatasetProfile>('/api/datasets/manual', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
  }

  async getDatasetProfile(datasetId: string): Promise<DatasetProfile> {
    return this.request<DatasetProfile>(`/api/datasets/${datasetId}/profile`);
  }

  async getDatasetPreview(
    datasetId: string,
    page: number = 1,
    pageSize: number = 25
  ): Promise<DatasetPreviewResponse> {
    return this.request<DatasetPreviewResponse>(
      `/api/datasets/${datasetId}/preview?page=${page}&page_size=${pageSize}`
    );
  }

  async deleteDataset(datasetId: string): Promise<void> {
    await this.request(`/api/datasets/${datasetId}`, {
      method: 'DELETE',
    });
  }

  async validateExperiment(config: ExperimentCreate): Promise<ValidationResponse> {
    return this.request<ValidationResponse>('/api/experiments/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
  }

  async trainExperiment(config: ExperimentCreate): Promise<ExperimentResult> {
    return this.request<ExperimentResult>('/api/experiments/train', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
  }

  async getExperiment(experimentId: string): Promise<ExperimentResult> {
    return this.request<ExperimentResult>(`/api/experiments/${experimentId}`);
  }

  async listExperiments(): Promise<ExperimentHistoryItem[]> {
    return this.request<ExperimentHistoryItem[]>('/api/experiments');
  }

  async predict(experimentId: string, inputs: Record<string, any>): Promise<PredictResponse> {
    return this.request<PredictResponse>(`/api/experiments/${experimentId}/predict`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ inputs }),
    });
  }
}

export const api = new ApiService();
