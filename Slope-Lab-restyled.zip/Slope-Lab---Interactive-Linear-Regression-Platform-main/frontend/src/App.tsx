import React, { useEffect, useState } from 'react';
import {
  DatasetProfile,
  ExperimentCreate,
  ExperimentHistoryItem,
  ExperimentResult,
  ModelConfig,
  PreprocessingConfig,
  SampleDatasetInfo,
  SplitConfig,
} from './types';
import { api } from './services/api';
import { Header } from './components/Header';
import { StageId, WorkflowNavigation } from './components/WorkflowNavigation';
import { DatasetImport } from './components/DatasetImport';
import { DatasetInspection } from './components/DatasetInspection';
import { FeatureSelector } from './components/FeatureSelector';
import { PreprocessingConfigPanel } from './components/PreprocessingConfigPanel';
import { SplitAndModelConfig } from './components/SplitAndModelConfig';
import { TrainingAndResults } from './components/TrainingAndResults';
import { PredictionPlayground } from './components/PredictionPlayground';
import { ExperimentHistoryModal } from './components/ExperimentHistoryModal';

export const App: React.FC = () => {
  // Navigation & Workflow Stage
  const [currentStage, setCurrentStage] = useState<StageId>('dataset');
  const [completedStages, setCompletedStages] = useState<Set<StageId>>(new Set());
  const [unlockedStages, setUnlockedStages] = useState<Set<StageId>>(new Set(['dataset']));

  // Backend Health
  const [backendHealthy, setBackendHealthy] = useState<boolean>(false);

  // Datasets
  const [samples, setSamples] = useState<SampleDatasetInfo[]>([]);
  const [activeProfile, setActiveProfile] = useState<DatasetProfile | null>(null);

  // Feature Selection
  const [selectedInputs, setSelectedInputs] = useState<string[]>([]);
  const [selectedTarget, setSelectedTarget] = useState<string>('');

  // Preprocessing
  const [preprocessingConfig, setPreprocessingConfig] = useState<PreprocessingConfig>({
    missing_value_strategies: {},
    missing_value_constants: {},
    missing_target_strategy: 'drop_row',
    scaling_strategies: {},
    encoding_strategies: {},
    ordinal_orders: {},
    handle_unknown_categorical: 'ignore',
    remove_duplicate_rows: false,
    remove_constant_features: true,
  });

  // Split & Model
  const [splitConfig, setSplitConfig] = useState<SplitConfig>({
    test_size: 0.2,
    random_state: 42,
    shuffle: true,
    split_mode: 'random',
  });

  const [modelConfig, setModelConfig] = useState<ModelConfig>({
    model_type: 'linear_regression',
    fit_intercept: true,
    positive: false,
    alpha: 1.0,
  });

  // Training & Results
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [trainingResult, setTrainingResult] = useState<ExperimentResult | null>(null);
  const [trainingError, setTrainingError] = useState<string | null>(null);

  // History
  const [experiments, setExperiments] = useState<ExperimentHistoryItem[]>([]);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState<boolean>(false);

  // 1. Initial Health Check & Data Loading
  useEffect(() => {
    let intervalId: any;

    const checkHealth = async () => {
      try {
        await api.getHealth();
        setBackendHealthy(true);
      } catch {
        setBackendHealthy(false);
      }
    };

    const loadSamplesAndHistory = async () => {
      try {
        const [sampleList, historyList] = await Promise.all([
          api.getSamples(),
          api.listExperiments(),
        ]);
        setSamples(sampleList);
        setExperiments(historyList);
      } catch (err) {
        console.error('Initial load failed', err);
      }
    };

    checkHealth();
    loadSamplesAndHistory();

    intervalId = setInterval(checkHealth, 15000);
    return () => clearInterval(intervalId);
  }, []);

  // 2. Handle Dataset Loading
  const handleDatasetLoaded = (profile: DatasetProfile) => {
    setActiveProfile(profile);

    // Auto-select smart initial target if none selected or not in dataset
    const numCols = profile.columns.filter((c) => c.inferred_type === 'numeric');
    let target = '';
    if (numCols.length > 0) {
      target = numCols[numCols.length - 1].name; // Default to last numeric column (conventional convention)
    }

    // Auto-select other columns as inputs
    const inputs = profile.columns
      .map((c) => c.name)
      .filter((c) => c !== target && c.toLowerCase() !== 'id' && c.toLowerCase() !== 'index');

    setSelectedTarget(target);
    setSelectedInputs(inputs);

    // Reset downstream experiment results
    setTrainingResult(null);
    setTrainingError(null);

    // Update workflow unlocking
    const newUnlocked = new Set(unlockedStages);
    newUnlocked.add('dataset');
    newUnlocked.add('profile');
    newUnlocked.add('features');
    newUnlocked.add('preprocessing');
    newUnlocked.add('split_model');
    setUnlockedStages(newUnlocked);

    const newCompleted = new Set(completedStages);
    newCompleted.add('dataset');
    setCompletedStages(newCompleted);

    // Advance to inspection stage
    setCurrentStage('profile');
  };

  // 3. Handle Feature Selection Update
  const handleUpdateFeatures = (inputs: string[], target: string) => {
    setSelectedInputs(inputs);
    setSelectedTarget(target);

    // Invalidate stale model
    if (trainingResult) {
      setTrainingResult(null);
    }
  };

  // 4. Handle Model Training
  const handleTrainModel = async () => {
    if (!activeProfile) return;

    setTrainingError(null);
    setIsTraining(true);

    const expConfig: ExperimentCreate = {
      dataset_id: activeProfile.id,
      name: `${activeProfile.name} [${modelConfig.model_type.toUpperCase()}]`,
      input_features: selectedInputs,
      target_feature: selectedTarget,
      preprocessing: preprocessingConfig,
      split: splitConfig,
      model: modelConfig,
    };

    try {
      const res = await api.trainExperiment(expConfig);
      setTrainingResult(res);

      // Refresh experiment history list
      api.listExperiments().then(setExperiments).catch(console.error);

      // Mark stages complete and unlock results & predict
      const newUnlocked = new Set(unlockedStages);
      newUnlocked.add('train_results');
      newUnlocked.add('predict');
      setUnlockedStages(newUnlocked);

      const newCompleted = new Set(completedStages);
      newCompleted.add('features');
      newCompleted.add('preprocessing');
      newCompleted.add('split_model');
      newCompleted.add('train_results');
      setCompletedStages(newCompleted);

      // Transition to results dashboard
      setCurrentStage('train_results');
    } catch (err: any) {
      setTrainingError(err.message || 'Model training failed.');
    } finally {
      setIsTraining(false);
    }
  };

  // 5. Handle Restoring an Experiment from History
  const handleSelectHistoricalExperiment = async (expId: string) => {
    try {
      const res = await api.getExperiment(expId);
      setTrainingResult(res);
      setSelectedInputs(res.config.input_features);
      setSelectedTarget(res.config.target_feature);
      setPreprocessingConfig(res.config.preprocessing);
      setSplitConfig(res.config.split);
      setModelConfig(res.config.model);

      // Fetch or restore profile
      try {
        const prof = await api.getDatasetProfile(res.dataset_id);
        setActiveProfile(prof);
      } catch {
        // Fallback
      }

      // Unlock stages
      setUnlockedStages(
        new Set([
          'dataset',
          'profile',
          'features',
          'preprocessing',
          'split_model',
          'train_results',
          'predict',
        ])
      );
      setCompletedStages(
        new Set(['dataset', 'profile', 'features', 'preprocessing', 'split_model', 'train_results'])
      );

      setCurrentStage('train_results');
    } catch (err: any) {
      alert(`Could not load experiment: ${err.message}`);
    }
  };

  // 6. Start New Experiment from scratch
  const handleNewExperiment = () => {
    setActiveProfile(null);
    setSelectedInputs([]);
    setSelectedTarget('');
    setTrainingResult(null);
    setTrainingError(null);
    setCompletedStages(new Set());
    setUnlockedStages(new Set(['dataset']));
    setCurrentStage('dataset');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-900">
      {/* Top Header */}
      <Header
        datasetName={activeProfile?.name}
        onNewExperiment={handleNewExperiment}
        onOpenHistory={() => setIsHistoryModalOpen(true)}
        historyCount={experiments.length}
        backendHealthy={backendHealthy}
      />

      {/* Persistent Workflow Stage Navigation Bar */}
      <WorkflowNavigation
        currentStage={currentStage}
        onSelectStage={setCurrentStage}
        completedStages={completedStages}
        unlockedStages={unlockedStages}
      />

      {/* Main Workspace Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 pb-16">
        {currentStage === 'dataset' && (
          <DatasetImport onDatasetLoaded={handleDatasetLoaded} samples={samples} />
        )}

        {currentStage === 'profile' && activeProfile && (
          <DatasetInspection
            profile={activeProfile}
            onProceed={() => {
              const newCompleted = new Set(completedStages);
              newCompleted.add('profile');
              setCompletedStages(newCompleted);
              setCurrentStage('features');
            }}
          />
        )}

        {currentStage === 'features' && activeProfile && (
          <FeatureSelector
            profile={activeProfile}
            selectedInputs={selectedInputs}
            selectedTarget={selectedTarget}
            onUpdateSelection={handleUpdateFeatures}
            onProceed={() => {
              const newCompleted = new Set(completedStages);
              newCompleted.add('features');
              setCompletedStages(newCompleted);
              setCurrentStage('preprocessing');
            }}
          />
        )}

        {currentStage === 'preprocessing' && activeProfile && (
          <PreprocessingConfigPanel
            profile={activeProfile}
            selectedInputs={selectedInputs}
            selectedTarget={selectedTarget}
            config={preprocessingConfig}
            onChangeConfig={setPreprocessingConfig}
            onProceed={() => {
              const newCompleted = new Set(completedStages);
              newCompleted.add('preprocessing');
              setCompletedStages(newCompleted);
              setCurrentStage('split_model');
            }}
          />
        )}

        {currentStage === 'split_model' && activeProfile && (
          <SplitAndModelConfig
            totalRows={activeProfile.row_count}
            splitConfig={splitConfig}
            modelConfig={modelConfig}
            onChangeSplit={setSplitConfig}
            onChangeModel={setModelConfig}
            onTrain={handleTrainModel}
            isTraining={isTraining}
            validationError={trainingError}
          />
        )}

        {currentStage === 'train_results' && trainingResult && (
          <TrainingAndResults
            result={trainingResult}
            onProceedToPrediction={() => setCurrentStage('predict')}
            onRetrainWithDifferentSettings={() => setCurrentStage('split_model')}
          />
        )}

        {currentStage === 'predict' && trainingResult && (
          <PredictionPlayground
            result={trainingResult}
            onRetrain={() => setCurrentStage('split_model')}
          />
        )}
      </main>

      {/* Experiment History Modal */}
      <ExperimentHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        experiments={experiments}
        onSelectExperiment={handleSelectHistoricalExperiment}
        currentExperimentId={trainingResult?.experiment_id}
      />
    </div>
  );
};

export default App;
