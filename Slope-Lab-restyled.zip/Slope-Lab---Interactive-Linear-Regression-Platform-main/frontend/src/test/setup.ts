import '@testing-library/jest-dom';

// Mock ResizeObserver for Recharts responsive containers in jsdom
global.ResizeObserver = class ResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
};
