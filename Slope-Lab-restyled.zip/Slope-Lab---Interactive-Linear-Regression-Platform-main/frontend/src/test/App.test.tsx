import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Header } from '../components/Header';
import { WorkflowNavigation } from '../components/WorkflowNavigation';
import { ManualDataEditor } from '../components/ManualDataEditor';
import { FeatureSelector } from '../components/FeatureSelector';
import { SplitAndModelConfig } from '../components/SplitAndModelConfig';
import { DatasetProfile, ExperimentResult } from '../types';

describe('Header component', () => {
  it('renders product title and tagline accurately', () => {
    render(
      <Header
        onNewExperiment={() => {}}
        onOpenHistory={() => {}}
        historyCount={2}
        backendHealthy={true}
      />
    );
    expect(screen.getByText('Slope Lab')).toBeInTheDocument();
    expect(screen.getByText('Understand how a model learns from data.')).toBeInTheDocument();
    expect(screen.getByText('Engine Active')).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
  });
});

describe('Workflow Navigation', () => {
  it('displays all 7 workflow stages with step progression', () => {
    const completed = new Set(['dataset', 'profile'] as const);
    const unlocked = new Set(['dataset', 'profile', 'features'] as const);

    render(
      <WorkflowNavigation
        currentStage="features"
        onSelectStage={() => {}}
        completedStages={completed}
        unlockedStages={unlocked}
      />
    );

    expect(screen.getByText('Dataset Import')).toBeInTheDocument();
    expect(screen.getByText('Inspect & Profile')).toBeInTheDocument();
    expect(screen.getByText('Feature Selection')).toBeInTheDocument();
    expect(screen.getByText('Preprocessing')).toBeInTheDocument();
    expect(screen.getByText('Split & Model')).toBeInTheDocument();
    expect(screen.getByText('Train & Results')).toBeInTheDocument();
    expect(screen.getByText('Predict')).toBeInTheDocument();
  });
});

describe('Manual Data Editor', () => {
  it('allows adding and removing rows and columns', () => {
    const handleSubmit = vi.fn();
    render(<ManualDataEditor onSubmit={handleSubmit} isSubmitting={false} />);

    // Check default features
    expect(screen.getByDisplayValue('Hours_Studied')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Exam_Score')).toBeInTheDocument();

    // Click "Add Row"
    const addRowBtn = screen.getByText('Add Row');
    fireEvent.click(addRowBtn);

    // Click "Add Feature"
    const addColBtn = screen.getByText('Add Feature');
    fireEvent.click(addColBtn);

    expect(screen.getByDisplayValue('Feature_4')).toBeInTheDocument();

    // Confirm submission
    const submitBtn = screen.getByText('Confirm & Proceed with Data');
    fireEvent.click(submitBtn);

    expect(handleSubmit).toHaveBeenCalledTimes(1);
    const submittedData = handleSubmit.mock.calls[0][0];
    expect(submittedData.columns).toContain('Feature_4');
    expect(submittedData.rows.length).toBe(11);
  });
});

describe('Feature Selector', () => {
  const mockProfile: DatasetProfile = {
    id: 'test_ds',
    name: 'Housing Test',
    format: 'CSV',
    row_count: 50,
    column_count: 4,
    duplicate_row_count: 0,
    has_missing_values: false,
    created_at: new Date().toISOString(),
    columns: [
      {
        name: 'Square_Feet',
        dtype: 'float64',
        inferred_type: 'numeric',
        missing_count: 0,
        missing_percentage: 0,
        unique_count: 40,
        unique_percentage: 80,
        sample_values: [1200, 1500, 1800],
        numeric_stats: { min: 1000, max: 3500, mean: 2000, median: 1900, std: 500, q25: 1500, q75: 2500 },
        issues: [],
      },
      {
        name: 'Bedrooms',
        dtype: 'int64',
        inferred_type: 'numeric',
        missing_count: 0,
        missing_percentage: 0,
        unique_count: 4,
        unique_percentage: 8,
        sample_values: [2, 3, 4],
        numeric_stats: { min: 1, max: 5, mean: 3, median: 3, std: 1, q25: 2, q75: 4 },
        issues: [],
      },
      {
        name: 'Location_Tier',
        dtype: 'object',
        inferred_type: 'categorical',
        missing_count: 0,
        missing_percentage: 0,
        unique_count: 3,
        unique_percentage: 6,
        sample_values: ['Suburban', 'Urban', 'Prime'],
        top_categories: [{ value: 'Suburban', count: 30, percentage: 60 }],
        issues: [],
      },
      {
        name: 'Sale_Price',
        dtype: 'float64',
        inferred_type: 'numeric',
        missing_count: 0,
        missing_percentage: 0,
        unique_count: 50,
        unique_percentage: 100,
        sample_values: [200000, 250000, 300000],
        numeric_stats: { min: 150000, max: 600000, mean: 320000, median: 300000, std: 100000, q25: 220000, q75: 400000 },
        issues: [],
      },
    ],
  };

  it('handles target selection and input toggles without overlap', () => {
    const handleUpdate = vi.fn();
    const handleProceed = vi.fn();

    render(
      <FeatureSelector
        profile={mockProfile}
        selectedInputs={['Square_Feet', 'Bedrooms']}
        selectedTarget="Sale_Price"
        onUpdateSelection={handleUpdate}
        onProceed={handleProceed}
      />
    );

    expect(screen.getAllByText('Sale_Price').length).toBeGreaterThan(0);
    expect(screen.getAllByText('Square_Feet').length).toBeGreaterThan(0);

    const proceedBtn = screen.getByText('Proceed to Preprocessing');
    expect(proceedBtn).not.toBeDisabled();
    fireEvent.click(proceedBtn);
    expect(handleProceed).toHaveBeenCalledTimes(1);
  });
});

describe('Split & Model Configuration', () => {
  it('updates split ratios and model parameters accurately', () => {
    const handleChangeSplit = vi.fn();
    const handleChangeModel = vi.fn();
    const handleTrain = vi.fn();

    render(
      <SplitAndModelConfig
        totalRows={100}
        splitConfig={{ test_size: 0.2, shuffle: true, split_mode: 'random' }}
        modelConfig={{ model_type: 'linear_regression', fit_intercept: true, positive: false, alpha: 1.0 }}
        onChangeSplit={handleChangeSplit}
        onChangeModel={handleChangeModel}
        onTrain={handleTrain}
        isTraining={false}
      />
    );

    // Verify row calculation display
    expect(screen.getByText(/Training Partition: 80 rows/)).toBeInTheDocument();
    expect(screen.getByText(/Testing Partition: 20 rows/)).toBeInTheDocument();

    // Click 75 / 25 preset
    const presetBtn = screen.getByText('75 / 25');
    fireEvent.click(presetBtn);
    expect(handleChangeSplit).toHaveBeenCalledWith(expect.objectContaining({ test_size: 0.25 }));

    // Click Train Model
    const trainBtn = screen.getByText('Train Model (Run Experiment)');
    fireEvent.click(trainBtn);
    expect(handleTrain).toHaveBeenCalledTimes(1);
  });
});
