export interface NumericStats {
  min: number;
  max: number;
  mean: number;
  median: number;
  std: number;
  q25: number;
  q75: number;
}

export interface CategoryFrequency {
  value: string;
  count: number;
  percentage: number;
}

export interface ColumnProfile {
  name: string;
  dtype: string;
  inferred_type: 'numeric' | 'categorical' | 'boolean' | 'datetime' | 'identifier';
  missing_count: number;
  missing_percentage: number;
  unique_count: number;
  unique_percentage: number;
  sample_values: (string | number | boolean | null)[];
  numeric_stats?: NumericStats | null;
  top_categories?: CategoryFrequency[] | null;
  issues: string[];
}

export interface DatasetProfile {
  id: string;
  name: string;
  format: string;
  row_count: number;
  column_count: number;
  duplicate_row_count: number;
  has_missing_values: boolean;
  columns: ColumnProfile[];
  created_at: string;
}

export interface DatasetPreviewResponse {
  dataset_id: string;
  columns: string[];
  rows: Record<string, any>[];
  total_rows: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface SampleDatasetInfo {
  id: string;
  name: string;
  description: string;
  row_count: number;
  feature_count: number;
  suggested_target: string;
}

export interface PreprocessingConfig {
  missing_value_strategies: Record<string, string>;
  missing_value_constants: Record<string, any>;
  missing_target_strategy: string;
  scaling_strategies: Record<string, string>;
  encoding_strategies: Record<string, string>;
  ordinal_orders: Record<string, string[]>;
  handle_unknown_categorical: 'ignore' | 'error';
  remove_duplicate_rows: boolean;
  remove_constant_features: boolean;
}

export interface SplitConfig {
  test_size: number;
  random_state?: number | null;
  shuffle: boolean;
  split_mode: 'random' | 'chronological';
}

export interface ModelConfig {
  model_type: 'linear_regression' | 'ridge' | 'lasso';
  fit_intercept: boolean;
  positive: boolean;
  alpha: number;
}

export interface ExperimentCreate {
  dataset_id: string;
  name: string;
  input_features: string[];
  target_feature: string;
  preprocessing: PreprocessingConfig;
  split: SplitConfig;
  model: ModelConfig;
}

export interface ValidationResponse {
  valid: boolean;
  errors: string[];
  warnings: string[];
  estimated_train_rows?: number | null;
  estimated_test_rows?: number | null;
  estimated_features_out?: number | null;
}

export interface MetricSummary {
  r2: number | null;
  mae: number | null;
  mse: number | null;
  rmse: number | null;
}

export interface CoefficientItem {
  feature_name: string;
  original_feature: string;
  coefficient: number;
  contribution_type: 'numeric' | 'categorical' | 'intercept';
  description: string;
}

export interface ChartPoint {
  index: number;
  actual: number;
  predicted: number;
  residual: number;
}

export interface ResidualBin {
  bin_start: number;
  bin_end: number;
  count: number;
}

export interface ExperimentResult {
  experiment_id: string;
  dataset_id: string;
  name: string;
  created_at: string;
  config: ExperimentCreate;
  train_rows: number;
  test_rows: number;
  total_features_in: number;
  total_features_out: number;
  transformed_feature_names: string[];
  intercept: number;
  coefficients: CoefficientItem[];
  metrics_test: MetricSummary;
  metrics_train: MetricSummary;
  scatter_data: ChartPoint[];
  residual_histogram: ResidualBin[];
  learning_insights: string[];
  warnings: string[];
}

export interface FeatureContribution {
  feature_name: string;
  original_feature: string;
  raw_value: any;
  transformed_value?: number | null;
  coefficient: number;
  contribution: number;
}

export interface PredictResponse {
  experiment_id: string;
  prediction: number;
  intercept: number;
  contributions: FeatureContribution[];
  raw_inputs: Record<string, any>;
  equation_formula: string;
}

export interface ExperimentHistoryItem {
  experiment_id: string;
  name: string;
  dataset_id: string;
  created_at: string;
  r2_test: number | null;
  rmse_test: number | null;
  model_type: string;
}
