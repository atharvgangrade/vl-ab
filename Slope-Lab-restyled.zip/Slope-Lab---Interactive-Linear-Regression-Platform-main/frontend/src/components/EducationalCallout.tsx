import React, { useState } from 'react';
import { BookOpen, ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

interface EducationalCalloutProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export const EducationalCallout: React.FC<EducationalCalloutProps> = ({
  title,
  children,
  defaultOpen = false,
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="border border-indigo-100 bg-indigo-50/40 rounded-lg overflow-hidden my-3 text-sm">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-3.5 py-2.5 text-left font-medium text-indigo-950 hover:bg-indigo-50/70 transition-colors"
      >
        <span className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>{title}</span>
        </span>
        {isOpen ? (
          <ChevronUp className="w-4 h-4 text-indigo-500 shrink-0" />
        ) : (
          <ChevronDown className="w-4 h-4 text-indigo-500 shrink-0" />
        )}
      </button>
      {isOpen && (
        <div className="px-3.5 pb-3 pt-1 text-slate-700 leading-relaxed border-t border-indigo-100/60 bg-white/70">
          {children}
        </div>
      )}
    </div>
  );
};

interface TooltipProps {
  content: string;
}

export const EducationalTooltip: React.FC<TooltipProps> = ({ content }) => {
  const [visible, setVisible] = useState(false);

  return (
    <span className="relative inline-flex items-center ml-1 align-middle">
      <button
        type="button"
        onMouseEnter={() => setVisible(true)}
        onMouseLeave={() => setVisible(false)}
        onClick={() => setVisible(!visible)}
        aria-label="Info"
        className="text-slate-400 hover:text-slate-600 focus:outline-none"
      >
        <HelpCircle className="w-3.5 h-3.5" />
      </button>
      {visible && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-64 p-2.5 bg-slate-900 text-slate-100 text-xs rounded-md shadow-lg z-50 pointer-events-none leading-normal">
          {content}
          <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-900" />
        </div>
      )}
    </span>
  );
};
