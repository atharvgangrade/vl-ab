import React from 'react';
import {
  AlertCircle,
  ArrowRight,
  Divide,
  PlayCircle,
  Shuffle,
  Sliders,
  Sparkles,
  Split,
} from 'lucide-react';
import { ModelConfig, SplitConfig } from '../types';
import { EducationalCallout, EducationalTooltip } from './EducationalCallout';

interface SplitAndModelConfigProps {
  totalRows: number;
  splitConfig: SplitConfig;
  modelConfig: ModelConfig;
  onChangeSplit: (newSplit: SplitConfig) => void;
  onChangeModel: (newModel: ModelConfig) => void;
  onTrain: () => void;
  isTraining: boolean;
  validationError?: string | null;
}

export const SplitAndModelConfig: React.FC<SplitAndModelConfigProps> = ({
  totalRows,
  splitConfig,
  modelConfig,
  onChangeSplit,
  onChangeModel,
  onTrain,
  isTraining,
  validationError,
}) => {
  const testPct = Math.round(splitConfig.test_size * 100);
  const trainPct = 100 - testPct;

  const testRows = Math.round(totalRows * splitConfig.test_size);
  const trainRows = totalRows - testRows;

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    onChangeSplit({
      ...splitConfig,
      test_size: Math.round(val) / 100,
    });
  };

  const handlePreset = (testFraction: number) => {
    onChangeSplit({
      ...splitConfig,
      test_size: testFraction,
    });
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
          <div>
            <span className="text-[11px] font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
              Stage 5 — Train-Test Partition & Model Selection
            </span>
            <h2 className="text-base font-semibold text-slate-900 mt-1">
              Configure Validation Split & Regression Estimator
            </h2>
            <p className="text-xs text-slate-500">
              Reserve an unseen test partition to honestly evaluate generalization, and configure the mathematical objective function for fitting.
            </p>
          </div>

          <button
            type="button"
            onClick={onTrain}
            disabled={isTraining || trainRows < 5 || testRows < 3}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-md transition-colors shadow-sm self-start md:self-auto cursor-pointer"
          >
            <PlayCircle className="w-4 h-4" />
            <span>{isTraining ? 'Fitting Estimator...' : 'Train Model (Run Experiment)'}</span>
          </button>
        </div>

        {validationError && (
          <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-md text-xs text-rose-800 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Validation Issue: </span>
              <span>{validationError}</span>
            </div>
          </div>
        )}
      </div>

      {/* 1. Train-Test Split Partition Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 mb-4 gap-2">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>1. Train-Test Split Ratio</span>
              <EducationalTooltip content="Training data is used to estimate the beta weights. Test data is kept strictly hidden to evaluate out-of-sample error." />
            </h3>
            <span className="text-[11px] text-slate-500">
              Total Observations: <strong className="font-mono text-slate-800">{totalRows} rows</strong>
            </span>
          </div>

          {/* Preset Buttons */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-400 text-[11px]">Presets:</span>
            {[
              { label: '80 / 20', val: 0.2 },
              { label: '75 / 25', val: 0.25 },
              { label: '70 / 30', val: 0.3 },
            ].map((p) => (
              <button
                key={p.val}
                type="button"
                onClick={() => handlePreset(p.val)}
                className={`px-2.5 py-1 rounded text-xs border font-mono transition-colors ${
                  splitConfig.test_size === p.val
                    ? 'bg-indigo-50 border-indigo-300 text-indigo-700 font-semibold'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Visual Partition Bar */}
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-indigo-700 font-semibold flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-indigo-600 inline-block" />
              Training Partition: {trainRows} rows ({trainPct}%)
            </span>
            <span className="text-amber-700 font-semibold flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-amber-500 inline-block" />
              Testing Partition: {testRows} rows ({testPct}%)
            </span>
          </div>

          <div className="w-full h-3 bg-slate-100 rounded-full flex overflow-hidden border border-slate-200">
            <div
              className="bg-indigo-600 h-full transition-all duration-150"
              style={{ width: `${trainPct}%` }}
            />
            <div
              className="bg-amber-500 h-full transition-all duration-150"
              style={{ width: `${testPct}%` }}
            />
          </div>
        </div>

        {/* Interactive Slider */}
        <div className="mt-4 pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
            <span>Test Partition Size:</span>
            <span className="font-mono font-bold text-slate-900">{testPct}% ({testRows} rows)</span>
          </div>
          <input
            type="range"
            min="10"
            max="40"
            step="1"
            value={testPct}
            onChange={handleSliderChange}
            className="w-full accent-indigo-600 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
            <span>10% test</span>
            <span>20% (Standard default)</span>
            <span>40% test</span>
          </div>
        </div>

        {/* Shuffling & Random Seed Controls */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="radio"
                name="split_mode"
                checked={splitConfig.split_mode === 'random'}
                onChange={() => onChangeSplit({ ...splitConfig, split_mode: 'random', shuffle: true })}
                className="text-indigo-600 focus:ring-indigo-500"
              />
              <span className="text-slate-700">Random Shuffled Split</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="radio"
                name="split_mode"
                checked={splitConfig.split_mode === 'chronological'}
                onChange={() =>
                  onChangeSplit({ ...splitConfig, split_mode: 'chronological', shuffle: false })
                }
                className="text-indigo-600 focus:ring-indigo-500"
              />
              <span className="text-slate-700">Chronological Split (Time-series / ordered)</span>
            </label>
          </div>

          {splitConfig.split_mode === 'random' && (
            <div className="flex items-center gap-2">
              <span className="text-slate-500 text-[11px]">Random Seed:</span>
              <input
                type="number"
                value={splitConfig.random_state ?? 42}
                onChange={(e) =>
                  onChangeSplit({ ...splitConfig, random_state: Number(e.target.value) || 0 })
                }
                className="w-16 px-2 py-0.5 text-xs font-mono border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          )}
        </div>
      </div>

      {/* 2. Model Selection and Hyperparameters Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="pb-3 border-b border-slate-200 mb-4">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <span>2. Model Algorithm & Hyperparameters</span>
            <EducationalTooltip content="Ordinary Least Squares (OLS) minimizes the sum of squared residuals. Ridge and Lasso introduce regularization penalties to control coefficient sizes." />
          </h3>
          <span className="text-[11px] text-slate-500">
            Select standard linear regression or regularized extensions for educational comparison.
          </span>
        </div>

        {/* Model Architecture Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
          {[
            {
              id: 'linear_regression',
              name: 'Ordinary Least Squares (OLS)',
              desc: 'Standard scikit-learn LinearRegression. Minimizes sum of squared errors with no penalty.',
            },
            {
              id: 'ridge',
              name: 'Ridge Regression (L2)',
              desc: 'Adds squared magnitude penalty (α ∑w²). Shrinks coefficients smoothly to combat collinearity.',
            },
            {
              id: 'lasso',
              name: 'Lasso Regression (L1)',
              desc: 'Adds absolute magnitude penalty (α ∑|w|). Capable of setting redundant coefficients to exactly zero.',
            },
          ].map((m) => {
            const isSelected = modelConfig.model_type === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => onChangeModel({ ...modelConfig, model_type: m.id as any })}
                className={`p-3.5 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/40 text-indigo-950 font-medium'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-900">{m.name}</span>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-indigo-600" />}
                </div>
                <p className="text-[11px] text-slate-500 leading-normal">{m.desc}</p>
              </button>
            );
          })}
        </div>

        {/* Hyperparameter Controls */}
        <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="font-semibold text-slate-800 block">Fit Intercept (β₀)</span>
              <span className="text-[11px] text-slate-500">
                Calculates the constant baseline intercept where all input features equal zero.
              </span>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={modelConfig.fit_intercept}
                onChange={(e) => onChangeModel({ ...modelConfig, fit_intercept: e.target.checked })}
                className="text-indigo-600 rounded focus:ring-indigo-500"
              />
              <span className="font-medium text-slate-700">Calculate Intercept (Recommended)</span>
            </label>
          </div>

          {modelConfig.model_type === 'linear_regression' && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-200">
              <div>
                <span className="font-semibold text-slate-800 block">Positive Coefficients Constraint</span>
                <span className="text-[11px] text-slate-500">
                  Forces all estimated weights to be non-negative (wᵢ ≥ 0).
                </span>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={modelConfig.positive}
                  onChange={(e) => onChangeModel({ ...modelConfig, positive: e.target.checked })}
                  className="text-indigo-600 rounded focus:ring-indigo-500"
                />
                <span className="font-medium text-slate-700">Constrain wᵢ ≥ 0</span>
              </label>
            </div>
          )}

          {(modelConfig.model_type === 'ridge' || modelConfig.model_type === 'lasso') && (
            <div className="pt-3 border-t border-slate-200">
              <div className="flex items-center justify-between mb-1.5">
                <div>
                  <span className="font-semibold text-slate-800 block">Regularization Strength (α / Alpha)</span>
                  <span className="text-[11px] text-slate-500">
                    Controls penalty balance. Higher values shrink weights more aggressively.
                  </span>
                </div>
                <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                  α = {modelConfig.alpha}
                </span>
              </div>
              <input
                type="range"
                min="0.01"
                max="10.0"
                step="0.05"
                value={modelConfig.alpha}
                onChange={(e) => onChangeModel({ ...modelConfig, alpha: Number(e.target.value) })}
                className="w-full accent-indigo-600 cursor-pointer"
              />
            </div>
          )}
        </div>
      </div>

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Concept: How does Ordinary Least Squares fit the line?">
        <p className="mb-2">
          The Ordinary Least Squares (OLS) objective minimizes the <strong>Residual Sum of Squares (RSS)</strong>:
        </p>
        <p className="font-mono text-xs bg-slate-100 p-2 rounded mb-2 border border-slate-200">
          RSS = ∑ (yᵢ - ŷᵢ)² = ∑ (yᵢ - (β₀ + β₁xᵢ₁ + ... + βₚxᵢₚ))²
        </p>
        <p>
          Unlike iterative neural networks that train via gradient descent over hundreds of epochs, linear regression has a closed-form analytical solution: <code>β = (XᵀX)⁻¹ Xᵀy</code>. When you click <strong>Train Model</strong>, the backend computes this exact solution on your processed training partition.
        </p>
      </EducationalCallout>
    </div>
  );
};
