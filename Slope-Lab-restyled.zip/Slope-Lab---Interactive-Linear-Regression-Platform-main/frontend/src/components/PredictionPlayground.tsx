import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Calculator,
  CheckCircle2,
  HelpCircle,
  Play,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { ExperimentResult, PredictResponse } from '../types';
import { api } from '../services/api';
import { EducationalCallout, EducationalTooltip } from './EducationalCallout';

interface PredictionPlaygroundProps {
  result: ExperimentResult;
  onRetrain: () => void;
}

export const PredictionPlayground: React.FC<PredictionPlaygroundProps> = ({
  result,
  onRetrain,
}) => {
  // Initialize input state with sensible defaults from feature sample values
  const [formInputs, setFormInputs] = useState<Record<string, any>>(() => {
    const initial: Record<string, any> = {};
    result.config.input_features.forEach((feat) => {
      // Find sample or mean value
      initial[feat] = '';
    });
    return initial;
  });

  const [predictionResult, setPredictionResult] = useState<PredictResponse | null>(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [predictionError, setPredictionError] = useState<string | null>(null);

  const handleInputChange = (featureName: string, val: any) => {
    setFormInputs({
      ...formInputs,
      [featureName]: val,
    });
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setPredictionError(null);
    setIsPredicting(true);

    // Coerce numeric inputs
    const formatted: Record<string, any> = {};
    result.config.input_features.forEach((feat) => {
      const raw = formInputs[feat];
      if (raw === '' || raw === null || raw === undefined) {
        formatted[feat] = null;
      } else {
        const num = Number(raw);
        formatted[feat] = isNaN(num) ? raw : num;
      }
    });

    try {
      const res = await api.predict(result.experiment_id, formatted);
      setPredictionResult(res);
    } catch (err: any) {
      setPredictionError(err.message || 'Prediction failed.');
    } finally {
      setIsPredicting(false);
    }
  };

  const handleResetInputs = () => {
    const blank: Record<string, any> = {};
    result.config.input_features.forEach((feat) => (blank[feat] = ''));
    setFormInputs(blank);
    setPredictionResult(null);
    setPredictionError(null);
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
          <div>
            <span className="text-[11px] font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
              Stage 7 — Interactive Inference Playground
            </span>
            <h2 className="text-base font-semibold text-slate-900 mt-1">
              Test the Model on Custom Unseen Scenarios
            </h2>
            <p className="text-xs text-slate-500">
              Supply new predictor values to the saved scikit-learn pipeline. Observe how the fitted imputers, scalers, encoders, and linear weights combine to produce predictions in real time.
            </p>
          </div>

          <button
            type="button"
            onClick={onRetrain}
            className="px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors self-start md:self-auto"
          >
            Modify Model & Retrain
          </button>
        </div>

        {predictionError && (
          <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-md text-xs text-rose-800 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Prediction Error: </span>
              <span>{predictionError}</span>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Dynamic Input Form (Left 5 cols) */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 lg:col-span-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Input Features Configuration
              </h3>
              <button
                type="button"
                onClick={handleResetInputs}
                className="text-[11px] text-slate-500 hover:text-slate-800 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Fields</span>
              </button>
            </div>

            <form onSubmit={handlePredict} className="space-y-3.5">
              {result.config.input_features.map((feat) => {
                const val = formInputs[feat] ?? '';
                return (
                  <div key={feat} className="text-xs">
                    <label className="block font-medium text-slate-800 mb-1 font-mono">
                      {feat}
                    </label>
                    <input
                      type="text"
                      value={val}
                      onChange={(e) => handleInputChange(feat, e.target.value)}
                      placeholder={`Enter value for ${feat}...`}
                      className="w-full px-3 py-1.5 text-xs font-mono border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-slate-50/50 focus:bg-white"
                    />
                  </div>
                );
              })}

              <div className="pt-3">
                <button
                  type="submit"
                  disabled={isPredicting}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-md transition-colors shadow-sm cursor-pointer"
                >
                  <Calculator className="w-4 h-4" />
                  <span>{isPredicting ? 'Computing Inference...' : 'Calculate Prediction'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Prediction Results & Linear Breakdown (Right 7 cols) */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 lg:col-span-7 flex flex-col justify-between">
          {predictionResult ? (
            <div>
              <div className="pb-3 border-b border-slate-200 mb-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-semibold tracking-wider uppercase text-slate-400">
                    Predicted Outcome (ŷ)
                  </span>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="text-3xl font-extrabold font-mono text-indigo-700 tracking-tight">
                      {predictionResult.prediction.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">
                      for target '{result.config.target_feature}'
                    </span>
                  </div>
                </div>
                <div className="p-2 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              </div>

              {/* Linear Decomposition Table */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <span>Linear Decomposition Breakdown: ŷ = β₀ + ∑(βⱼ · zⱼ)</span>
                  <EducationalTooltip content="Shows how each feature multiplied by its weight contributes positively or negatively to the final prediction." />
                </h4>

                <div className="overflow-x-auto border border-slate-200 rounded text-xs">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-medium">
                        <th className="p-2">Feature / Term</th>
                        <th className="p-2 font-mono text-right">Raw Value</th>
                        <th className="p-2 font-mono text-right">Transformed (z)</th>
                        <th className="p-2 font-mono text-right">Weight (β)</th>
                        <th className="p-2 font-mono text-right font-semibold">Contribution</th>
                      </tr>
                    </thead>
                    <tbody>
                      {/* Intercept Row */}
                      <tr className="border-b border-slate-100 bg-indigo-50/20 font-mono">
                        <td className="p-2 font-semibold text-indigo-950">β₀ Intercept</td>
                        <td className="p-2 text-right text-slate-400">—</td>
                        <td className="p-2 text-right text-slate-400">1.0</td>
                        <td className="p-2 text-right text-indigo-900">{predictionResult.intercept}</td>
                        <td className="p-2 text-right font-bold text-indigo-950">
                          {predictionResult.intercept > 0 ? `+${predictionResult.intercept}` : predictionResult.intercept}
                        </td>
                      </tr>

                      {/* Feature rows */}
                      {predictionResult.contributions.map((c) => (
                        <tr key={c.feature_name} className="border-b border-slate-100 hover:bg-slate-50/50 font-mono">
                          <td className="p-2 font-medium text-slate-800">{c.feature_name}</td>
                          <td className="p-2 text-right text-slate-600 truncate max-w-[80px]">
                            {c.raw_value !== null ? String(c.raw_value) : 'null'}
                          </td>
                          <td className="p-2 text-right text-slate-600">
                            {c.transformed_value !== null ? c.transformed_value : '—'}
                          </td>
                          <td className="p-2 text-right text-slate-600">{c.coefficient}</td>
                          <td
                            className={`p-2 text-right font-bold ${
                              c.contribution >= 0 ? 'text-indigo-900' : 'text-rose-700'
                            }`}
                          >
                            {c.contribution > 0 ? `+${c.contribution}` : c.contribution}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
              <Calculator className="w-10 h-10 mb-2 text-slate-300 stroke-[1.5]" />
              <h4 className="text-sm font-semibold text-slate-700">Awaiting Prediction Inputs</h4>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Enter values in the form on the left and click <strong>Calculate Prediction</strong> to evaluate this fitted linear regression pipeline.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Concept: Interpreting Predictions through Feature Contributions">
        <p className="mb-2">
          One of the greatest pedagogical strengths of Linear Regression is its <strong>complete mathematical transparency</strong>. Unlike black-box neural networks, every single prediction is an exact linear combination of feature values weighted by estimated parameters.
        </p>
        <p>
          By inspecting the <strong>Linear Decomposition Breakdown</strong> table above, you can see precisely how much each input pulled the prediction above or below the baseline intercept.
        </p>
      </EducationalCallout>
    </div>
  );
};
