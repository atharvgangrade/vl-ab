import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  Database,
  Layers,
  Percent,
  Sliders,
  Sparkles,
} from 'lucide-react';
import { ColumnProfile, DatasetProfile, PreprocessingConfig } from '../types';
import { EducationalCallout, EducationalTooltip } from './EducationalCallout';

interface PreprocessingConfigPanelProps {
  profile: DatasetProfile;
  selectedInputs: string[];
  selectedTarget: string;
  config: PreprocessingConfig;
  onChangeConfig: (newConfig: PreprocessingConfig) => void;
  onProceed: () => void;
}

export const PreprocessingConfigPanel: React.FC<PreprocessingConfigPanelProps> = ({
  profile,
  selectedInputs,
  selectedTarget,
  config,
  onChangeConfig,
  onProceed,
}) => {
  const selectedProfiles = profile.columns.filter((c) => selectedInputs.includes(c.name));
  const numericInputs = selectedProfiles.filter((c) => c.inferred_type === 'numeric');
  const categoricalInputs = selectedProfiles.filter(
    (c) => c.inferred_type === 'categorical' || c.inferred_type === 'boolean' || c.inferred_type === 'identifier'
  );

  const handleMissingStrategyChange = (colName: string, strat: string) => {
    onChangeConfig({
      ...config,
      missing_value_strategies: {
        ...config.missing_value_strategies,
        [colName]: strat,
      },
    });
  };

  const handleScalingStrategyChange = (colName: string, scaler: string) => {
    onChangeConfig({
      ...config,
      scaling_strategies: {
        ...config.scaling_strategies,
        [colName]: scaler,
      },
    });
  };

  const handleBulkScaling = (scaler: string) => {
    const updated: Record<string, string> = { ...config.scaling_strategies };
    numericInputs.forEach((col) => {
      updated[col.name] = scaler;
    });
    onChangeConfig({
      ...config,
      scaling_strategies: updated,
    });
  };

  const handleEncodingStrategyChange = (colName: string, enc: string) => {
    onChangeConfig({
      ...config,
      encoding_strategies: {
        ...config.encoding_strategies,
        [colName]: enc,
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
          <div>
            <span className="text-[11px] font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
              Stage 4 — Preprocessing & Transformation
            </span>
            <h2 className="text-base font-semibold text-slate-900 mt-1">
              Configure Pipeline Transformations
            </h2>
            <p className="text-xs text-slate-500">
              Define how missing values are imputed, categorical variables encoded, and numerical features scaled. All transformations are strictly fitted on the <strong>training split only</strong> to prevent data leakage.
            </p>
          </div>

          <button
            type="button"
            onClick={onProceed}
            className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors shadow-sm self-start md:self-auto"
          >
            <span>Proceed to Train-Test Split</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Global cleaning toggles */}
        <div className="mt-4 flex flex-wrap items-center gap-6 text-xs text-slate-700">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={config.remove_duplicate_rows}
              onChange={(e) =>
                onChangeConfig({ ...config, remove_duplicate_rows: e.target.checked })
              }
              className="text-indigo-600 rounded focus:ring-indigo-500"
            />
            <span>Deduplicate training rows</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={config.remove_constant_features}
              onChange={(e) =>
                onChangeConfig({ ...config, remove_constant_features: e.target.checked })
              }
              className="text-indigo-600 rounded focus:ring-indigo-500"
            />
            <span>Drop zero-variance (constant) features</span>
          </label>
        </div>
      </div>

      {/* 1. Missing Value Strategy */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>1. Missing-Value Handling Strategy</span>
              <EducationalTooltip content="Linear models cannot compute dot products with NaN/null values. Strategies replace missing cells with estimated summaries." />
            </h3>
            <span className="text-[11px] text-slate-500">
              {profile.has_missing_values
                ? 'Missing values detected in dataset. Configure imputation per feature.'
                : 'No missing values currently present. Configurations act as safety fallbacks.'}
            </span>
          </div>

          {profile.has_missing_values ? (
            <span className="text-[10px] font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
              Active Missing Cells
            </span>
          ) : (
            <span className="text-[10px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1">
              <Check className="w-3 h-3" />
              Dataset 100% Complete
            </span>
          )}
        </div>

        <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
          {selectedProfiles.map((col) => {
            const isNumeric = col.inferred_type === 'numeric';
            const currentStrat =
              config.missing_value_strategies[col.name] || (isNumeric ? 'median' : 'most_frequent');

            return (
              <div
                key={col.name}
                className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-md border border-slate-100 bg-slate-50/50 text-xs gap-2"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono font-medium text-slate-900">{col.name}</span>
                  <span className="text-[10px] font-mono text-slate-400">
                    ({isNumeric ? 'Numeric' : 'Categorical'} • {col.missing_count} nulls)
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={currentStrat}
                    onChange={(e) => handleMissingStrategyChange(col.name, e.target.value)}
                    className="text-xs bg-white border border-slate-200 rounded px-2.5 py-1 text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    {isNumeric ? (
                      <>
                        <option value="median">Median Imputation (Robust to outliers)</option>
                        <option value="mean">Mean Imputation</option>
                        <option value="constant">Constant (Zero)</option>
                      </>
                    ) : (
                      <>
                        <option value="most_frequent">Most Frequent Category (Mode)</option>
                        <option value="constant">Constant ("missing" category)</option>
                      </>
                    )}
                  </select>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Feature Scaling Configuration (Numeric Only) */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 mb-4 gap-2">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <span>2. Feature Scaling Configuration (Numerical Predictors)</span>
              <EducationalTooltip content="Transforms features onto comparable numeric scales. Fit exclusively on the training partition." />
            </h3>
            <span className="text-[11px] text-slate-500">
              Standardize or normalize features so that coefficients represent comparable relative importance.
            </span>
          </div>

          {numericInputs.length > 0 && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 text-[11px]">Apply to all:</span>
              <select
                onChange={(e) => handleBulkScaling(e.target.value)}
                defaultValue=""
                className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 text-slate-700"
              >
                <option value="" disabled>
                  Bulk select scaler...
                </option>
                <option value="standard">StandardScaler (Mean 0, Std 1)</option>
                <option value="minmax">MinMaxScaler (Range [0, 1])</option>
                <option value="robust">RobustScaler (Median / IQR)</option>
                <option value="none">No Scaling (Original Units)</option>
              </select>
            </div>
          )}
        </div>

        {numericInputs.length > 0 ? (
          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {numericInputs.map((col) => {
              const currentScaler = config.scaling_strategies[col.name] || 'none';
              return (
                <div
                  key={col.name}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-md border border-slate-100 bg-slate-50/50 text-xs gap-2"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-medium text-slate-900">{col.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      (Range: {col.numeric_stats?.min} to {col.numeric_stats?.max})
                    </span>
                  </div>

                  <select
                    value={currentScaler}
                    onChange={(e) => handleScalingStrategyChange(col.name, e.target.value)}
                    className="text-xs bg-white border border-slate-200 rounded px-2.5 py-1 text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="none">No Scaling (Preserve Original Units)</option>
                    <option value="standard">StandardScaler (z = (x - μ) / σ)</option>
                    <option value="minmax">MinMaxScaler (Scale to 0.0 — 1.0)</option>
                    <option value="robust">RobustScaler (Outlier-resistant IQR)</option>
                    <option value="maxabs">MaxAbsScaler (Scale by absolute max)</option>
                  </select>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-slate-400 italic">No numeric input features selected.</p>
        )}
      </div>

      {/* 3. Categorical Encoding (Categorical Only) */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="pb-3 border-b border-slate-200 mb-4">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
            <span>3. Categorical Encoding (Non-Numerical Predictors)</span>
            <EducationalTooltip content="Linear models require numeric matrices. One-Hot creates binary indicator columns; Ordinal assigns integer ranks." />
          </h3>
          <span className="text-[11px] text-slate-500">
            Convert qualitative categories into numeric formats suitable for matrix multiplication.
          </span>
        </div>

        {categoricalInputs.length > 0 ? (
          <div className="space-y-2.5">
            {categoricalInputs.map((col) => {
              const currentEnc = config.encoding_strategies[col.name] || 'onehot';
              return (
                <div
                  key={col.name}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-md border border-slate-100 bg-slate-50/50 text-xs gap-2"
                >
                  <div>
                    <span className="font-mono font-medium text-slate-900">{col.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono block">
                      {col.unique_count} categories (e.g. {col.sample_values.slice(0, 3).join(', ')})
                    </span>
                  </div>

                  <select
                    value={currentEnc}
                    onChange={(e) => handleEncodingStrategyChange(col.name, e.target.value)}
                    className="text-xs bg-white border border-slate-200 rounded px-2.5 py-1 text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="onehot">One-Hot Encoding (Binary Dummy Columns)</option>
                    <option value="ordinal">Ordinal Encoding (Integer Ranks)</option>
                  </select>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-slate-400 italic">
            No categorical or string features selected as inputs.
          </p>
        )}
      </div>

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Concept: Why is Preprocessing Data Leakage so Dangerous?">
        <p className="mb-2">
          <strong>Data Leakage</strong> happens whenever statistical information from the test dataset contaminates the training stage.
        </p>
        <p className="mb-2">
          If you compute the mean of a feature across the <em>entire dataset</em> to standardize or impute missing values before splitting, your model has already learned properties of the unseen test distribution.
        </p>
        <p>
          In Slope Lab, the dataset is split first into independent partitions. Imputers and scalers are fitted exclusively on the <strong>training set</strong>, and the resulting parameters are applied untouched to test observations and live predictions.
        </p>
      </EducationalCallout>
    </div>
  );
};
