import React, { useState } from 'react';
import {
  ArrowRight,
  BarChart2,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Cpu,
  FileText,
  Info,
  Layers,
  LineChart as LineChartIcon,
  PlayCircle,
  Sparkles,
  Table,
  TrendingUp,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ExperimentResult } from '../types';
import { EducationalCallout, EducationalTooltip } from './EducationalCallout';

interface TrainingAndResultsProps {
  result: ExperimentResult;
  onProceedToPrediction: () => void;
  onRetrainWithDifferentSettings: () => void;
}

export const TrainingAndResults: React.FC<TrainingAndResultsProps> = ({
  result,
  onProceedToPrediction,
  onRetrainWithDifferentSettings,
}) => {
  const [activeChartTab, setActiveChartTab] = useState<
    'actual_vs_pred' | 'residuals' | 'histogram' | 'coefficients'
  >('actual_vs_pred');

  const { metrics_test, metrics_train, coefficients, intercept } = result;

  // Prepare 45-degree reference line min/max for Actual vs Predicted
  const actualVals = result.scatter_data.map((d) => d.actual);
  const predVals = result.scatter_data.map((d) => d.predicted);
  const allScatterVals = [...actualVals, ...predVals];
  const minVal = allScatterVals.length > 0 ? Math.floor(Math.min(...allScatterVals)) : 0;
  const maxVal = allScatterVals.length > 0 ? Math.ceil(Math.max(...allScatterVals)) : 100;

  // Format equation formula
  const topCoeffs = coefficients.slice(0, 4);
  const equationParts = topCoeffs.map(
    (c) => `${c.coefficient >= 0 ? '+' : '-'} ${Math.abs(c.coefficient)} · ${c.feature_name}`
  );
  const formattedEquation = `ŷ = ${intercept} ${equationParts.join(' ')}${
    coefficients.length > 4 ? ` + ... (${coefficients.length - 4} more terms)` : ''
  }`;

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-semibold tracking-wider uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                Stage 6 — Model Fitted Successfully
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Experiment ID: {result.experiment_id}
              </span>
            </div>
            <h2 className="text-base font-semibold text-slate-900 mt-1">
              Scientific Evaluation & Diagnostic Report
            </h2>
            <p className="text-xs text-slate-500">
              Estimator: <strong className="font-mono text-slate-800 uppercase">{result.config.model.model_type}</strong> • Fitted on {result.train_rows} training rows, evaluated on {result.test_rows} test rows across {result.total_features_out} transformed features.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              type="button"
              onClick={onRetrainWithDifferentSettings}
              className="px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
            >
              Adjust Settings & Retrain
            </button>
            <button
              type="button"
              onClick={onProceedToPrediction}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors shadow-sm"
            >
              <span>Interactive Prediction Playground</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 4 Summary Metrics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 text-xs">
          {/* R2 Card */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-500 font-medium">Test R² Score</span>
              <EducationalTooltip content="Coefficient of determination: the proportion of variance in the test target explained by the linear model. Can be negative if predictions are worse than the baseline mean." />
            </div>
            <span
              className={`text-xl font-bold font-mono ${
                metrics_test.r2 !== null && metrics_test.r2 >= 0.7
                  ? 'text-emerald-700'
                  : metrics_test.r2 !== null && metrics_test.r2 >= 0.4
                  ? 'text-indigo-700'
                  : 'text-amber-700'
              }`}
            >
              {metrics_test.r2 !== null ? metrics_test.r2.toFixed(4) : 'N/A'}
            </span>
            <span className="block text-[10px] text-slate-400 mt-1 font-mono">
              Train R²: {metrics_train.r2 !== null ? metrics_train.r2.toFixed(4) : 'N/A'}
            </span>
          </div>

          {/* RMSE Card */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-500 font-medium">Root Mean Sq. Error (RMSE)</span>
              <EducationalTooltip content="Square root of the average squared errors. Expressed in the exact same physical units as the target variable." />
            </div>
            <span className="text-xl font-bold font-mono text-slate-900">
              {metrics_test.rmse !== null ? metrics_test.rmse.toLocaleString() : 'N/A'}
            </span>
            <span className="block text-[10px] text-slate-400 mt-1 font-mono">
              Train RMSE: {metrics_train.rmse !== null ? metrics_train.rmse.toLocaleString() : 'N/A'}
            </span>
          </div>

          {/* MAE Card */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-500 font-medium">Mean Absolute Error (MAE)</span>
              <EducationalTooltip content="Average absolute difference between actual target and predicted target. Less sensitive to extreme outliers than RMSE." />
            </div>
            <span className="text-xl font-bold font-mono text-slate-900">
              {metrics_test.mae !== null ? metrics_test.mae.toLocaleString() : 'N/A'}
            </span>
            <span className="block text-[10px] text-slate-400 mt-1 font-mono">
              Train MAE: {metrics_train.mae !== null ? metrics_train.mae.toLocaleString() : 'N/A'}
            </span>
          </div>

          {/* MSE Card */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between mb-1">
              <span className="text-slate-500 font-medium">Mean Squared Error (MSE)</span>
              <EducationalTooltip content="Mean of squared prediction residuals. Penalizes large prediction errors quadratically." />
            </div>
            <span className="text-xl font-bold font-mono text-slate-900 truncate">
              {metrics_test.mse !== null ? metrics_test.mse.toExponential(3) : 'N/A'}
            </span>
            <span className="block text-[10px] text-slate-400 mt-1 font-mono truncate">
              Train MSE: {metrics_train.mse !== null ? metrics_train.mse.toExponential(3) : 'N/A'}
            </span>
          </div>
        </div>

        {/* Data-Grounded Learning Observations */}
        {result.learning_insights.length > 0 && (
          <div className="mt-4 p-3 bg-indigo-50/50 border border-indigo-100 rounded-lg text-xs text-indigo-950">
            <div className="flex items-center gap-1.5 font-semibold text-indigo-900 mb-1">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Grounded Empirical Observations from Results</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-700 text-[11px] pl-1">
              {result.learning_insights.map((insight, idx) => (
                <li key={idx} className="leading-relaxed">
                  {insight}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Fitted Mathematical Equation Display */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <span>Fitted Regression Hyperplane Equation</span>
          <EducationalTooltip content="The exact mathematical linear formula estimated by OLS on the transformed feature matrix." />
        </h3>
        <div className="bg-slate-50 p-3 rounded-md border border-slate-200 overflow-x-auto font-mono text-xs text-indigo-950 leading-relaxed">
          {formattedEquation}
        </div>
      </div>

      {/* Diagnostic Visualizations Suite */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 mb-4 gap-2">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Diagnostic Visualizations Suite
          </h3>

          {/* Visualization Tab Controls */}
          <div className="flex items-center gap-1 text-xs">
            {[
              { id: 'actual_vs_pred', label: '1. Actual vs Predicted' },
              { id: 'residuals', label: '2. Residuals vs Predicted' },
              { id: 'histogram', label: '3. Residual Distribution' },
              { id: 'coefficients', label: '4. Feature Coefficients' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveChartTab(tab.id as any)}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  activeChartTab === tab.id
                    ? 'bg-indigo-600 text-white font-medium shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Chart View 1: Actual vs Predicted */}
        {activeChartTab === 'actual_vs_pred' && (
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span>
                Points closer to the diagonal reference line (<strong className="text-indigo-600">y = ŷ</strong>) indicate superior model accuracy.
              </span>
              <span className="font-mono text-[11px]">N = {result.scatter_data.length} test points</span>
            </div>
            <div className="w-full h-80 bg-slate-50/50 rounded border border-slate-100 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#d9dfd6" />
                  <XAxis
                    type="number"
                    dataKey="actual"
                    name="Actual Value"
                    stroke="#66736a"
                    fontSize={11}
                    tickFormatter={(v) => Number(v).toLocaleString()}
                    label={{ value: 'Actual Observed Target', position: 'bottom', offset: 0, fontSize: 11 }}
                  />
                  <YAxis
                    type="number"
                    dataKey="predicted"
                    name="Predicted Value"
                    stroke="#66736a"
                    fontSize={11}
                    tickFormatter={(v) => Number(v).toLocaleString()}
                    label={{ value: 'Model Prediction (ŷ)', angle: -90, position: 'left', offset: 0, fontSize: 11 }}
                  />
                  <Tooltip
                    cursor={{ strokeDasharray: '3 3' }}
                    content={({ payload }) => {
                      if (!payload || !payload.length) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded shadow-lg font-mono">
                          <p>Obs #{data.index + 1}</p>
                          <p className="text-emerald-400">Actual: {data.actual.toLocaleString()}</p>
                          <p className="text-indigo-300">Predicted: {data.predicted.toLocaleString()}</p>
                          <p className="text-slate-400">Error: {data.residual.toLocaleString()}</p>
                        </div>
                      );
                    }}
                  />
                  {/* Diagonal reference line */}
                  <ReferenceLine
                    segment={[
                      { x: minVal, y: minVal },
                      { x: maxVal, y: maxVal },
                    ]}
                    stroke="#0b7164"
                    strokeWidth={2}
                    strokeDasharray="4 4"
                    label={{ value: 'Perfect Fit (y = ŷ)', position: 'top', fill: '#0b7164', fontSize: 10 }}
                  />
                  <Scatter data={result.scatter_data} fill="#0a5a50" opacity={0.7} />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Chart View 2: Residuals vs Predicted */}
        {activeChartTab === 'residuals' && (
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span>
                Residuals should scatter randomly around zero without funneling (heteroscedasticity) or curved patterns.
              </span>
              <span className="font-mono text-[11px]">Residual = y - ŷ</span>
            </div>
            <div className="w-full h-80 bg-slate-50/50 rounded border border-slate-100 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#d9dfd6" />
                  <XAxis
                    type="number"
                    dataKey="predicted"
                    name="Predicted Value"
                    stroke="#66736a"
                    fontSize={11}
                    tickFormatter={(v) => Number(v).toLocaleString()}
                    label={{ value: 'Predicted Value (ŷ)', position: 'bottom', offset: 0, fontSize: 11 }}
                  />
                  <YAxis
                    type="number"
                    dataKey="residual"
                    name="Residual Error"
                    stroke="#66736a"
                    fontSize={11}
                    tickFormatter={(v) => Number(v).toLocaleString()}
                    label={{ value: 'Residual (y - ŷ)', angle: -90, position: 'left', offset: 0, fontSize: 11 }}
                  />
                  <Tooltip
                    cursor={{ strokeDasharray: '3 3' }}
                    content={({ payload }) => {
                      if (!payload || !payload.length) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded shadow-lg font-mono">
                          <p>Predicted: {data.predicted.toLocaleString()}</p>
                          <p className="text-amber-400">Residual: {data.residual.toLocaleString()}</p>
                          <p className="text-slate-400">Actual: {data.actual.toLocaleString()}</p>
                        </div>
                      );
                    }}
                  />
                  {/* Zero reference line */}
                  <ReferenceLine
                    y={0}
                    stroke="#c93719"
                    strokeWidth={2}
                    label={{ value: 'Zero Residual Baseline', position: 'right', fill: '#c93719', fontSize: 10 }}
                  />
                  <Scatter data={result.scatter_data} fill="#148a79" opacity={0.7} />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Chart View 3: Residual Distribution Histogram */}
        {activeChartTab === 'histogram' && (
          <div>
            <div className="text-xs text-slate-500 mb-2">
              A bell-shaped distribution centered near zero supports the classical OLS assumption of normally distributed errors.
            </div>
            <div className="w-full h-80 bg-slate-50/50 rounded border border-slate-100 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={result.residual_histogram}
                  margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#d9dfd6" />
                  <XAxis
                    dataKey="bin_start"
                    stroke="#66736a"
                    fontSize={10}
                    tickFormatter={(v) => Number(v).toFixed(1)}
                    label={{ value: 'Residual Error Bins', position: 'bottom', offset: 0, fontSize: 11 }}
                  />
                  <YAxis
                    dataKey="count"
                    stroke="#66736a"
                    fontSize={11}
                    label={{ value: 'Frequency Count', angle: -90, position: 'left', offset: 0, fontSize: 11 }}
                  />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || !payload.length) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded shadow-lg font-mono">
                          <p>
                            Range: [{data.bin_start} to {data.bin_end}]
                          </p>
                          <p className="text-indigo-300 font-semibold">Count: {data.count} observations</p>
                        </div>
                      );
                    }}
                  />
                  <Bar dataKey="count" fill="#0b7164" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Chart View 4: Feature Coefficients Bar Chart */}
        {activeChartTab === 'coefficients' && (
          <div>
            <div className="text-xs text-slate-500 mb-2">
              Estimated weights (β) across all transformed features. Features with positive weights increase the prediction; negative weights decrease it.
            </div>
            <div className="w-full h-80 bg-slate-50/50 rounded border border-slate-100 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={result.coefficients}
                  margin={{ top: 10, right: 30, bottom: 10, left: 100 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#d9dfd6" />
                  <XAxis
                    type="number"
                    stroke="#66736a"
                    fontSize={11}
                    tickFormatter={(v) => Number(v).toLocaleString()}
                  />
                  <YAxis
                    type="category"
                    dataKey="feature_name"
                    stroke="#66736a"
                    fontSize={10}
                    width={95}
                  />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || !payload.length) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded shadow-lg font-mono">
                          <p className="font-bold">{data.feature_name}</p>
                          <p className="text-indigo-300">Weight: {data.coefficient}</p>
                          <p className="text-slate-400 text-[10px]">{data.description}</p>
                        </div>
                      );
                    }}
                  />
                  <ReferenceLine x={0} stroke="#8e9a8a" />
                  <Bar dataKey="coefficient">
                    {result.coefficients.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.coefficient >= 0 ? '#0a5a50' : '#c93719'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>

      {/* Model Coefficients Detail Table */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
          Estimated Parameters Table (Weights & Intercept)
        </h3>

        <div className="overflow-x-auto border border-slate-200 rounded">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700">
                <th className="p-2.5 font-semibold">Feature Parameter</th>
                <th className="p-2.5 font-semibold">Original Column</th>
                <th className="p-2.5 font-semibold">Representation Type</th>
                <th className="p-2.5 font-semibold font-mono text-right">Estimated β</th>
                <th className="p-2.5 font-semibold">Pedagogical Interpretation</th>
              </tr>
            </thead>
            <tbody>
              {/* Intercept Row */}
              <tr className="border-b border-slate-100 bg-indigo-50/20">
                <td className="p-2.5 font-mono font-bold text-indigo-950">β₀ (Intercept)</td>
                <td className="p-2.5 text-slate-500 italic">—</td>
                <td className="p-2.5">
                  <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border bg-indigo-50 text-indigo-700 border-indigo-200">
                    Bias / Offset
                  </span>
                </td>
                <td className="p-2.5 font-mono font-bold text-right text-indigo-950">
                  {intercept.toFixed(4)}
                </td>
                <td className="p-2.5 text-slate-600">
                  Baseline predicted outcome when all input features equal zero.
                </td>
              </tr>

              {/* Coefficients */}
              {coefficients.map((item) => (
                <tr key={item.feature_name} className="border-b border-slate-100 hover:bg-slate-50/60">
                  <td className="p-2.5 font-mono font-medium text-slate-900">
                    {item.feature_name}
                  </td>
                  <td className="p-2.5 font-mono text-slate-500">{item.original_feature}</td>
                  <td className="p-2.5">
                    <span
                      className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border ${
                        item.contribution_type === 'numeric'
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : 'bg-purple-50 text-purple-700 border-purple-200'
                      }`}
                    >
                      {item.contribution_type}
                    </span>
                  </td>
                  <td
                    className={`p-2.5 font-mono font-bold text-right ${
                      item.coefficient >= 0 ? 'text-indigo-900' : 'text-rose-700'
                    }`}
                  >
                    {item.coefficient > 0 ? `+${item.coefficient.toFixed(4)}` : item.coefficient.toFixed(4)}
                  </td>
                  <td className="p-2.5 text-slate-600 leading-normal">{item.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Concept: Interpreting Coefficients & Correlation vs Causation">
        <p className="mb-2">
          A regression coefficient (<strong>βⱼ</strong>) represents the expected change in the target variable for a one-unit change in that feature, <em>holding all other variables constant</em> (ceteris paribus).
        </p>
        <p className="mb-2">
          <strong>Crucial Principle:</strong> Regression coefficients reflect mathematical associations in the sample distribution, <strong>not causal proof</strong>. Confounding variables, omitted predictors, or selection bias can make an irrelevant feature appear statistically significant.
        </p>
        <p>
          Also, if you applied <code>StandardScaler</code>, a 1-unit increase corresponds to a 1 standard deviation shift (z-score), allowing you to directly compare relative influence between features measured in different units!
        </p>
      </EducationalCallout>
    </div>
  );
};
