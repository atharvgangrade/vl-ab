import React, { useState } from 'react';
import { AlertCircle, Clipboard, Plus, Trash2 } from 'lucide-react';

interface ManualDataEditorProps {
  onSubmit: (data: { name: string; columns: string[]; rows: Record<string, any>[] }) => void;
  isSubmitting: boolean;
}

export const ManualDataEditor: React.FC<ManualDataEditorProps> = ({
  onSubmit,
  isSubmitting,
}) => {
  const [datasetName, setDatasetName] = useState('Manual Experiment Data');
  const [columns, setColumns] = useState<string[]>(['Hours_Studied', 'Attendance_Rate', 'Exam_Score']);
  const [columnTypes, setColumnTypes] = useState<Record<string, string>>({
    Hours_Studied: 'numeric',
    Attendance_Rate: 'numeric',
    Exam_Score: 'numeric',
  });
  const [rows, setRows] = useState<string[][]>([
    ['2.5', '75', '65'],
    ['5.0', '85', '78'],
    ['7.0', '92', '88'],
    ['1.5', '60', '52'],
    ['6.0', '89', '84'],
    ['3.5', '80', '71'],
    ['8.0', '98', '94'],
    ['4.0', '82', '74'],
    ['6.5', '90', '86'],
    ['2.0', '68', '60'],
  ]);
  const [pasteText, setPasteText] = useState('');
  const [showPasteModal, setShowPasteModal] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAddRow = () => {
    setRows([...rows, new Array(columns.length).fill('')]);
  };

  const handleRemoveRow = (index: number) => {
    if (rows.length <= 5) {
      setError('A minimum of 5 rows is required for training.');
      return;
    }
    setError(null);
    setRows(rows.filter((_, i) => i !== index));
  };

  const handleAddColumn = () => {
    const newColName = `Feature_${columns.length + 1}`;
    setColumns([...columns, newColName]);
    setColumnTypes({ ...columnTypes, [newColName]: 'numeric' });
    setRows(rows.map((row) => [...row, '']));
  };

  const handleRemoveColumn = (colIdx: number) => {
    if (columns.length <= 2) {
      setError('At least 2 columns are required (at least 1 input and 1 target).');
      return;
    }
    setError(null);
    const colName = columns[colIdx];
    const newCols = columns.filter((_, i) => i !== colIdx);
    const newTypes = { ...columnTypes };
    delete newTypes[colName];

    setColumns(newCols);
    setColumnTypes(newTypes);
    setRows(rows.map((row) => row.filter((_, i) => i !== colIdx)));
  };

  const handleColumnNameChange = (colIdx: number, newName: string) => {
    const trimmed = newName.trim();
    const oldName = columns[colIdx];
    const newCols = [...columns];
    newCols[colIdx] = trimmed;
    setColumns(newCols);

    const newTypes = { ...columnTypes };
    const currType = newTypes[oldName] || 'numeric';
    delete newTypes[oldName];
    newTypes[trimmed] = currType;
    setColumnTypes(newTypes);
  };

  const handleCellChange = (rowIdx: number, colIdx: number, value: string) => {
    const updated = [...rows];
    updated[rowIdx] = [...updated[rowIdx]];
    updated[rowIdx][colIdx] = value;
    setRows(updated);
  };

  const handlePasteTabularData = () => {
    if (!pasteText.trim()) return;

    try {
      const lines = pasteText.trim().split(/\r?\n/).map((line) => line.split(/\t|,/));
      if (lines.length < 2) {
        setError('Pasted text must contain at least a header line and one data row.');
        return;
      }

      const headers = lines[0].map((h, i) => h.trim() || `col_${i + 1}`);
      const dataRows = lines.slice(1).map((r) => {
        // Pad or truncate to header length
        const row = new Array(headers.length).fill('');
        r.forEach((val, i) => {
          if (i < headers.length) row[i] = val.trim();
        });
        return row;
      });

      setColumns(headers);
      const types: Record<string, string> = {};
      headers.forEach((h) => (types[h] = 'numeric'));
      setColumnTypes(types);
      setRows(dataRows);
      setShowPasteModal(false);
      setPasteText('');
      setError(null);
    } catch (err: any) {
      setError(`Failed to parse pasted data: ${err.message}`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    const emptyCols = columns.some((c) => !c.trim());
    if (emptyCols) {
      setError('All column headers must have non-empty names.');
      return;
    }

    const uniqueCols = new Set(columns.map((c) => c.toLowerCase()));
    if (uniqueCols.size !== columns.length) {
      setError('Duplicate column names detected. Column names must be unique.');
      return;
    }

    if (rows.length < 5) {
      setError('Please provide at least 5 rows for training and evaluation.');
      return;
    }

    // Convert rows into record objects
    const formattedRows: Record<string, any>[] = rows.map((r) => {
      const obj: Record<string, any> = {};
      columns.forEach((col, idx) => {
        const val = r[idx]?.trim() ?? '';
        if (val === '') {
          obj[col] = null;
        } else if (columnTypes[col] === 'numeric') {
          const num = Number(val);
          obj[col] = isNaN(num) ? null : num;
        } else {
          obj[col] = val;
        }
      });
      return obj;
    });

    onSubmit({
      name: datasetName.trim() || 'Manual Dataset',
      columns,
      rows: formattedRows,
    });
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">Manual Data Entry Laboratory</h2>
          <p className="text-xs text-slate-500">
            Edit cells directly, configure data types, or paste from spreadsheets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowPasteModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md transition-colors"
          >
            <Clipboard className="w-3.5 h-3.5 text-slate-500" />
            <span>Paste Table</span>
          </button>
          <button
            type="button"
            onClick={handleAddColumn}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-slate-500" />
            <span>Add Feature</span>
          </button>
          <button
            type="button"
            onClick={handleAddRow}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-slate-500" />
            <span>Add Row</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="my-3 flex items-start gap-2 p-2.5 rounded-md bg-rose-50 border border-rose-200 text-rose-700 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Dataset Name */}
      <div className="my-3">
        <label className="block text-xs font-medium text-slate-700 mb-1">Dataset Name</label>
        <input
          type="text"
          value={datasetName}
          onChange={(e) => setDatasetName(e.target.value)}
          className="text-xs px-2.5 py-1.5 border border-slate-200 rounded-md w-full max-w-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
          placeholder="e.g. Student Exam Hours"
        />
      </div>

      {/* Spreadsheet grid */}
      <div className="overflow-x-auto border border-slate-200 rounded-md max-h-96">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200 text-left">
              <th className="p-2 w-10 text-slate-400 font-mono text-center">#</th>
              {columns.map((col, cIdx) => (
                <th key={cIdx} className="p-2 min-w-[140px] border-r border-slate-200">
                  <div className="flex items-center gap-1.5 mb-1">
                    <input
                      type="text"
                      value={col}
                      onChange={(e) => handleColumnNameChange(cIdx, e.target.value)}
                      className="font-medium text-slate-800 bg-white border border-slate-200 px-1.5 py-0.5 rounded text-xs w-full focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveColumn(cIdx)}
                      className="text-slate-400 hover:text-rose-600 p-0.5"
                      title="Remove column"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <select
                    value={columnTypes[col] || 'numeric'}
                    onChange={(e) =>
                      setColumnTypes({ ...columnTypes, [col]: e.target.value })
                    }
                    className="text-[10px] bg-slate-100 text-slate-600 rounded px-1 py-0.5 border border-slate-200 w-full"
                  >
                    <option value="numeric">Type: Numeric (Float)</option>
                    <option value="categorical">Type: Categorical</option>
                  </select>
                </th>
              ))}
              <th className="p-2 w-10 text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rIdx) => (
              <tr key={rIdx} className="border-b border-slate-100 hover:bg-slate-50/50">
                <td className="p-2 text-center font-mono text-[11px] text-slate-400 bg-slate-50/30">
                  {rIdx + 1}
                </td>
                {row.map((val, cIdx) => (
                  <td key={cIdx} className="p-1 border-r border-slate-100">
                    <input
                      type="text"
                      value={val}
                      onChange={(e) => handleCellChange(rIdx, cIdx, e.target.value)}
                      placeholder="empty / null"
                      className="w-full px-2 py-1 bg-transparent text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-400 rounded"
                    />
                  </td>
                ))}
                <td className="p-1 text-center">
                  <button
                    type="button"
                    onClick={() => handleRemoveRow(rIdx)}
                    className="text-slate-300 hover:text-rose-600 p-1"
                    title="Remove row"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4">
        <span className="text-xs text-slate-500">
          Showing {rows.length} observations and {columns.length} columns.
        </span>
        <button
          type="button"
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-md transition-colors shadow-sm"
        >
          {isSubmitting ? 'Validating Dataset...' : 'Confirm & Proceed with Data'}
        </button>
      </div>

      {/* Paste Modal */}
      {showPasteModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg border border-slate-200 max-w-lg w-full p-5 shadow-xl">
            <h3 className="text-sm font-semibold text-slate-900 mb-1">
              Paste Spreadsheet Data
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              Copy tabular cells from Excel or Google Sheets (tab or comma separated), including header row, and paste here:
            </p>
            <textarea
              rows={8}
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
              placeholder="Hours	Score&#10;3.5	75&#10;4.0	82"
              className="w-full font-mono text-xs p-2.5 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <div className="flex items-center justify-end gap-2 mt-3">
              <button
                type="button"
                onClick={() => setShowPasteModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handlePasteTabularData}
                className="px-3 py-1.5 text-xs font-medium bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Parse & Insert Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
