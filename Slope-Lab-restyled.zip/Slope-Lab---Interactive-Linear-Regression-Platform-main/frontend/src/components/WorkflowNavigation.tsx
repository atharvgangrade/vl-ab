import React from 'react';
import {
  Check,
  Database,
  FileSearch,
  Filter,
  PlayCircle,
  Sliders,
  Sparkles,
  Split,
} from 'lucide-react';

export type StageId =
  | 'dataset'
  | 'profile'
  | 'features'
  | 'preprocessing'
  | 'split_model'
  | 'train_results'
  | 'predict';

interface Stage {
  id: StageId;
  label: string;
  stepNumber: number;
  icon: React.ElementType;
}

const STAGES: Stage[] = [
  { id: 'dataset', label: 'Dataset Import', stepNumber: 1, icon: Database },
  { id: 'profile', label: 'Inspect & Profile', stepNumber: 2, icon: FileSearch },
  { id: 'features', label: 'Feature Selection', stepNumber: 3, icon: Filter },
  { id: 'preprocessing', label: 'Preprocessing', stepNumber: 4, icon: Sliders },
  { id: 'split_model', label: 'Split & Model', stepNumber: 5, icon: Split },
  { id: 'train_results', label: 'Train & Results', stepNumber: 6, icon: PlayCircle },
  { id: 'predict', label: 'Predict', stepNumber: 7, icon: Sparkles },
];

interface WorkflowNavigationProps {
  currentStage: StageId;
  onSelectStage: (stage: StageId) => void;
  completedStages: Set<StageId>;
  unlockedStages: Set<StageId>;
}

export const WorkflowNavigation: React.FC<WorkflowNavigationProps> = ({
  currentStage,
  onSelectStage,
  completedStages,
  unlockedStages,
}) => {
  return (
    <nav className="bg-slate-50/95 border-b border-slate-300 overflow-x-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <ol className="flex items-stretch min-w-max text-xs">
          {STAGES.map((stage) => {
            const isActive = currentStage === stage.id;
            const isCompleted = completedStages.has(stage.id);
            const isUnlocked = unlockedStages.has(stage.id);

            return (
              <li key={stage.id} className="flex">
                <button
                  type="button"
                  disabled={!isUnlocked}
                  onClick={() => onSelectStage(stage.id)}
                  className={`flex items-center gap-2 px-4 py-3 -mb-px border-b-[3px] transition-colors ${
                    isActive
                      ? 'border-indigo-600 text-slate-900 font-semibold bg-white'
                      : isCompleted
                      ? 'border-emerald-500 text-slate-800 hover:bg-white/70 cursor-pointer font-medium'
                      : isUnlocked
                      ? 'border-transparent text-slate-600 hover:bg-white/70 cursor-pointer font-medium'
                      : 'border-transparent text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-semibold font-mono ${
                      isActive
                        ? 'bg-indigo-600 text-white'
                        : isCompleted
                        ? 'bg-emerald-600 text-white'
                        : 'border border-slate-300 text-slate-500'
                    }`}
                  >
                    {isCompleted && !isActive ? (
                      <Check className="w-3 h-3 stroke-[3]" />
                    ) : (
                      stage.stepNumber
                    )}
                  </span>
                  <span className="truncate">{stage.label}</span>
                </button>
              </li>
            );
          })}
        </ol>
      </div>
    </nav>
  );
};
