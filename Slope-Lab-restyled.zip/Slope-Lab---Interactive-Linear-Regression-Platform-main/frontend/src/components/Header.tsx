import React from 'react';
import { History, RotateCcw } from 'lucide-react';

interface HeaderProps {
  datasetName?: string;
  onNewExperiment: () => void;
  onOpenHistory: () => void;
  historyCount: number;
  backendHealthy: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  datasetName,
  onNewExperiment,
  onOpenHistory,
  historyCount,
  backendHealthy,
}) => {
  return (
    <header className="bg-slate-900 text-slate-50 sticky top-0 z-40 px-4 sm:px-6 py-3 border-b-4 border-indigo-600">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand identity: a best-fit line through scattered points */}
        <div className="flex items-center gap-3">
          <svg viewBox="0 0 40 40" className="w-9 h-9 shrink-0" aria-hidden="true">
            <rect x="1" y="1" width="38" height="38" rx="2" fill="#f4f6f3" />
            <line x1="5" y1="33" x2="35" y2="7" stroke="#c93719" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="10" cy="26" r="2.6" fill="#151c18" />
            <circle cx="17" cy="25" r="2.6" fill="#151c18" />
            <circle cx="22" cy="15" r="2.6" fill="#151c18" />
            <circle cx="30" cy="14" r="2.6" fill="#151c18" />
          </svg>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white leading-none">
                Slope Lab
              </h1>
              <span className="hidden sm:inline text-[11px] font-medium px-2 py-0.5 rounded border border-slate-600 text-slate-300">
                Machine Learning Lab
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block mt-1">
              Understand how a model learns from data.
            </p>
          </div>
        </div>

        {/* Current status & actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {datasetName && (
            <div className="hidden md:flex items-center gap-1.5 text-xs bg-slate-800 px-2.5 py-1.5 rounded-md border border-slate-700">
              <span className="text-slate-400">Dataset:</span>
              <span className="font-medium text-white truncate max-w-[150px]">{datasetName}</span>
            </div>
          )}

          {/* Backend Status indicator */}
          <div className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border border-slate-700 bg-slate-800">
            <span
              className={`w-2 h-2 rounded-full ${
                backendHealthy ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
              }`}
            />
            <span className="text-slate-300 hidden sm:inline">
              {backendHealthy ? 'Engine Active' : 'Connecting...'}
            </span>
          </div>

          {/* History modal trigger */}
          <button
            type="button"
            onClick={onOpenHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-900 bg-amber-300 hover:bg-amber-200 rounded-md transition-colors"
          >
            <History className="w-3.5 h-3.5" />
            <span>History</span>
            {historyCount > 0 && (
              <span className="bg-slate-900 text-amber-200 text-[10px] font-semibold px-1.5 rounded-full">
                {historyCount}
              </span>
            )}
          </button>

          {/* Reset / New experiment */}
          <button
            type="button"
            onClick={onNewExperiment}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-100 hover:text-white border border-slate-600 hover:bg-slate-800 rounded-md transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New Experiment</span>
          </button>
        </div>
      </div>
    </header>
  );
};
