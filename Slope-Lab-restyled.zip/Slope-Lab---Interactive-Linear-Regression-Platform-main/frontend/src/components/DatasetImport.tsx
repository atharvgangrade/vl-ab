import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Database,
  FileSpreadsheet,
  FileText,
  PenTool,
  Upload,
} from 'lucide-react';
import { DatasetProfile, SampleDatasetInfo } from '../types';
import { api } from '../services/api';
import { ManualDataEditor } from './ManualDataEditor';
import { EducationalCallout } from './EducationalCallout';

interface DatasetImportProps {
  onDatasetLoaded: (profile: DatasetProfile) => void;
  samples: SampleDatasetInfo[];
}

export const DatasetImport: React.FC<DatasetImportProps> = ({
  onDatasetLoaded,
  samples,
}) => {
  const [activeTab, setActiveTab] = useState<'samples' | 'upload' | 'manual'>('samples');
  const [isUploading, setIsUploading] = useState(false);
  const [loadingSampleId, setLoadingSampleId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage(null);
    setIsUploading(true);

    try {
      const profile = await api.uploadDataset(file);
      onDatasetLoaded(profile);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to upload dataset.');
    } finally {
      setIsUploading(false);
      // Reset input value
      e.target.value = '';
    }
  };

  const handleSelectSample = async (sampleId: string) => {
    setErrorMessage(null);
    setLoadingSampleId(sampleId);

    try {
      const profile = await api.loadSample(sampleId);
      onDatasetLoaded(profile);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load sample dataset.');
    } finally {
      setLoadingSampleId(null);
    }
  };

  const handleManualSubmit = async (data: {
    name: string;
    columns: string[];
    rows: Record<string, any>[];
  }) => {
    setErrorMessage(null);
    setIsUploading(true);

    try {
      const profile = await api.createManualDataset(data);
      onDatasetLoaded(profile);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to create dataset from manual input.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Editorial Introduction */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="max-w-3xl">
          <span className="text-[11px] font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
            Stage 1 — Introduce Data
          </span>
          <h2 className="text-lg font-semibold text-slate-900 mt-2">
            Import or Choose an Empirical Dataset
          </h2>
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">
            Machine learning models do not learn in a vacuum; they uncover quantitative relationships from structured observations. Choose a curated sample dataset designed for regression exploration, upload your own data file, or compose a custom dataset manually.
          </p>
        </div>

        {/* Tab selection */}
        <div className="flex border-b border-slate-200 mt-5 space-x-6 text-xs">
          <button
            type="button"
            onClick={() => {
              setActiveTab('samples');
              setErrorMessage(null);
            }}
            className={`pb-2.5 font-medium flex items-center gap-1.5 transition-colors border-b-2 -mb-px ${
              activeTab === 'samples'
                ? 'border-indigo-600 text-indigo-700 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Curated Sample Datasets</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('upload');
              setErrorMessage(null);
            }}
            className={`pb-2.5 font-medium flex items-center gap-1.5 transition-colors border-b-2 -mb-px ${
              activeTab === 'upload'
                ? 'border-indigo-600 text-indigo-700 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload File (CSV, Excel, JSON)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('manual');
              setErrorMessage(null);
            }}
            className={`pb-2.5 font-medium flex items-center gap-1.5 transition-colors border-b-2 -mb-px ${
              activeTab === 'manual'
                ? 'border-indigo-600 text-indigo-700 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>Manual Spreadsheet Entry</span>
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="flex items-start gap-2.5 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Dataset Import Error: </span>
            <span>{errorMessage}</span>
          </div>
        </div>
      )}

      {/* Tab 1: Samples */}
      {activeTab === 'samples' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {samples.map((sample) => (
            <div
              key={sample.id}
              className="bg-white border border-slate-200 rounded-lg p-5 flex flex-col justify-between hover:border-indigo-200 transition-colors shadow-xs"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                  <span className="font-mono text-[11px] bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                    {sample.row_count} rows × {sample.feature_count} cols
                  </span>
                  <span className="text-[11px] text-indigo-600 font-medium">Standard Study</span>
                </div>
                <h3 className="text-sm font-semibold text-slate-900 mb-1.5">
                  {sample.name}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  {sample.description}
                </p>
                <div className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded border border-slate-100 mb-4">
                  <span className="text-slate-400">Target outcome: </span>
                  <span className="font-mono font-medium text-slate-800">{sample.suggested_target}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleSelectSample(sample.id)}
                disabled={loadingSampleId !== null}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 rounded-md transition-colors"
              >
                <span>{loadingSampleId === sample.id ? 'Loading...' : 'Load Dataset'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Upload File */}
      {activeTab === 'upload' && (
        <div className="bg-white border border-slate-200 rounded-lg p-6">
          <div className="max-w-xl mx-auto text-center py-6">
            <div className="w-12 h-12 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900 mb-1">
              Select or Drop a Tabular Dataset
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Supported formats: <strong>.csv</strong>, <strong>.xlsx</strong>, <strong>.xls</strong>, <strong>.json</strong> (tabular array). Maximum file size: 25 MB.
            </p>

            <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md cursor-pointer transition-colors shadow-sm">
              <FileSpreadsheet className="w-4 h-4" />
              <span>{isUploading ? 'Validating and Parsing...' : 'Browse Local Files'}</span>
              <input
                type="file"
                accept=".csv,.xlsx,.xls,.json"
                onChange={handleFileUpload}
                disabled={isUploading}
                className="hidden"
              />
            </label>

            <div className="mt-6 pt-4 border-t border-slate-100 text-left text-xs text-slate-500 space-y-1">
              <p>• Header names are automatically sanitized and deduplicated.</p>
              <p>• Missing numerical and categorical entries will be detected during profiling.</p>
              <p>• The file is preserved securely in your local environment without any third-party clouds.</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Manual Entry */}
      {activeTab === 'manual' && (
        <ManualDataEditor onSubmit={handleManualSubmit} isSubmitting={isUploading} />
      )}

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Workflow Concept: What makes a good dataset for Linear Regression?">
        <p className="mb-2">
          Linear Regression seeks to find an optimal hyper-plane:
        </p>
        <p className="font-mono text-xs bg-slate-100 p-2 rounded mb-2 border border-slate-200">
          ŷ = β₀ + β₁X₁ + β₂X₂ + ... + βₚXₚ
        </p>
        <p>
          For linear regression to perform well, the target variable (<strong>y</strong>) must be continuous and numeric (e.g. house price, test score, revenue). The input variables (<strong>X</strong>) can be numeric or categorical, but categorical variables must be appropriately encoded before estimating the coefficients.
        </p>
      </EducationalCallout>
    </div>
  );
};
