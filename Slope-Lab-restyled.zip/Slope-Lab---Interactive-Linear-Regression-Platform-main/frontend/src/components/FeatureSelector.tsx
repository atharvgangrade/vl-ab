import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Check,
  CheckSquare,
  Filter,
  HelpCircle,
  Search,
  Square,
  Target,
} from 'lucide-react';
import { ColumnProfile, DatasetProfile } from '../types';
import { EducationalCallout, EducationalTooltip } from './EducationalCallout';

interface FeatureSelectorProps {
  profile: DatasetProfile;
  selectedInputs: string[];
  selectedTarget: string;
  onUpdateSelection: (inputs: string[], target: string) => void;
  onProceed: () => void;
}

export const FeatureSelector: React.FC<FeatureSelectorProps> = ({
  profile,
  selectedInputs,
  selectedTarget,
  onUpdateSelection,
  onProceed,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const numericColumns = profile.columns.filter((c) => c.inferred_type === 'numeric');
  const availableTargetColumns = numericColumns;

  // Filter columns by search query
  const filteredColumns = profile.columns.filter((c) =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleInput = (colName: string) => {
    if (colName === selectedTarget) return; // Cannot be input and target

    if (selectedInputs.includes(colName)) {
      onUpdateSelection(
        selectedInputs.filter((c) => c !== colName),
        selectedTarget
      );
    } else {
      onUpdateSelection([...selectedInputs, colName], selectedTarget);
    }
  };

  const handleSelectAllInputs = () => {
    // Select all available columns except the target
    const allExceptTarget = profile.columns
      .map((c) => c.name)
      .filter((c) => c !== selectedTarget);
    onUpdateSelection(allExceptTarget, selectedTarget);
  };

  const handleSelectAllNumericInputs = () => {
    const numericExceptTarget = numericColumns
      .map((c) => c.name)
      .filter((c) => c !== selectedTarget);
    onUpdateSelection(numericExceptTarget, selectedTarget);
  };

  const handleClearInputs = () => {
    onUpdateSelection([], selectedTarget);
  };

  const handleTargetChange = (newTarget: string) => {
    // If new target was previously an input, remove it from inputs
    const updatedInputs = selectedInputs.filter((c) => c !== newTarget);
    onUpdateSelection(updatedInputs, newTarget);
  };

  const targetProfile = profile.columns.find((c) => c.name === selectedTarget);
  const isValid = selectedTarget !== '' && selectedInputs.length > 0;

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
          <div>
            <span className="text-[11px] font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
              Stage 3 — Feature Selection
            </span>
            <h2 className="text-base font-semibold text-slate-900 mt-1">
              Designate Input Predictors (X) & Target Variable (y)
            </h2>
            <p className="text-xs text-slate-500">
              Linear regression models the relationship: <code className="font-mono text-indigo-700">y = f(X)</code>. Select exactly one numeric target and at least one input feature.
            </p>
          </div>

          <button
            type="button"
            disabled={!isValid}
            onClick={onProceed}
            className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-md transition-colors shadow-sm self-start md:self-auto"
          >
            <span>Proceed to Preprocessing</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Validation Errors & Warnings */}
        {!isValid && (
          <div className="mt-3 p-2.5 bg-amber-50 border border-amber-200 rounded-md text-xs text-amber-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              {!selectedTarget
                ? 'Select a target variable (y) to proceed.'
                : 'Select at least one input feature (X) to proceed.'}
            </span>
          </div>
        )}
      </div>

      {/* Target (y) Selection Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-200 mb-4">
          <div className="w-6 h-6 rounded bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center font-bold text-xs">
            y
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1">
              <span>Target / Output Variable (y)</span>
              <EducationalTooltip content="The dependent variable that your linear regression model aims to predict. Must be quantitative and numerical." />
            </h3>
            <span className="text-[11px] text-slate-500">
              Must be a numeric column with sufficient variation.
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {availableTargetColumns.map((col) => {
            const isTarget = col.name === selectedTarget;
            return (
              <label
                key={col.name}
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-colors flex items-start gap-2.5 ${
                  isTarget
                    ? 'border-rose-500 bg-rose-50/40 text-rose-950 font-medium'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="target_column"
                  checked={isTarget}
                  onChange={() => handleTargetChange(col.name)}
                  className="mt-0.5 text-rose-600 focus:ring-rose-500"
                />
                <div className="overflow-hidden">
                  <span className="block font-mono font-medium truncate">{col.name}</span>
                  <span className="text-[11px] text-slate-500 block">
                    Mean: {col.numeric_stats?.mean ?? 'N/A'} • {col.missing_count === 0 ? 'No nulls' : `${col.missing_count} nulls`}
                  </span>
                </div>
              </label>
            );
          })}
        </div>

        {availableTargetColumns.length === 0 && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded text-xs text-rose-700">
            No suitable numeric target columns detected in this dataset.
          </div>
        )}
      </div>

      {/* Input Features (X) Selection Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-indigo-50 text-indigo-600 border border-indigo-200 flex items-center justify-center font-bold text-xs">
              X
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1">
                <span>Input Predictor Features (X)</span>
                <EducationalTooltip content="Independent variables fed into the model. Can include both numeric and categorical features." />
              </h3>
              <span className="text-[11px] text-slate-500">
                Selected {selectedInputs.length} of {profile.columns.length - 1} eligible features.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick buttons */}
            <button
              type="button"
              onClick={handleSelectAllNumericInputs}
              className="text-[11px] font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2 py-1 rounded"
            >
              Select All Numeric
            </button>
            <button
              type="button"
              onClick={handleSelectAllInputs}
              className="text-[11px] font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2 py-1 rounded"
            >
              Select All
            </button>
            <button
              type="button"
              onClick={handleClearInputs}
              className="text-[11px] font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2 py-1 rounded"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search features by name..."
            className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Feature Checkbox Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredColumns.map((col) => {
            const isTarget = col.name === selectedTarget;
            const isSelected = selectedInputs.includes(col.name);
            const hasIdIssue = col.inferred_type === 'identifier';
            const hasHighCardIssue = col.issues.some((i) => i.toLowerCase().includes('cardinality'));

            return (
              <label
                key={col.name}
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-colors flex items-start gap-2.5 ${
                  isTarget
                    ? 'opacity-40 bg-slate-100 border-slate-200 cursor-not-allowed'
                    : isSelected
                    ? 'border-indigo-500 bg-indigo-50/40 text-indigo-950 font-medium'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <input
                  type="checkbox"
                  disabled={isTarget}
                  checked={isSelected}
                  onChange={() => handleToggleInput(col.name)}
                  className="mt-0.5 text-indigo-600 rounded focus:ring-indigo-500"
                />
                <div className="overflow-hidden w-full">
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-mono font-medium truncate">{col.name}</span>
                    <span
                      className={`text-[9px] uppercase px-1 py-0.2 rounded border font-mono shrink-0 ${
                        col.inferred_type === 'numeric'
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : col.inferred_type === 'categorical'
                          ? 'bg-purple-50 text-purple-700 border-purple-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                      }`}
                    >
                      {col.inferred_type}
                    </span>
                  </div>

                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {col.unique_count} unique • {col.missing_count === 0 ? 'No nulls' : `${col.missing_percentage}% null`}
                  </span>

                  {hasIdIssue && (
                    <span className="text-[10px] text-amber-700 flex items-center gap-1 mt-1 font-sans">
                      <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                      <span>Likely identifier (low utility)</span>
                    </span>
                  )}
                  {hasHighCardIssue && (
                    <span className="text-[10px] text-amber-700 flex items-center gap-1 mt-1 font-sans">
                      <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0" />
                      <span>High cardinality warning</span>
                    </span>
                  )}
                  {isTarget && (
                    <span className="text-[10px] text-rose-600 block mt-1 font-sans">
                      Selected as target (y)
                    </span>
                  )}
                </div>
              </label>
            );
          })}
        </div>
      </div>

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Concept: Feature Selection & The Danger of Target Leakage">
        <p className="mb-2">
          In regression, input features must only contain information that would be realistically available at prediction time.
        </p>
        <p className="mb-2">
          <strong>Target Leakage</strong> occurs when a predictor feature directly reflects or is derived from the target variable itself (e.g. including "Total Exam Points" when predicting "Final Letter Grade"). The model appears to achieve near-perfect training accuracy but fails completely on real unseen data.
        </p>
        <p>
          Additionally, beware of <strong>Identifiers</strong> (like Student ID or House Index). Linear models will assign arbitrary weights to sequential numbers, learning spurious noise rather than genuine causal relationships.
        </p>
      </EducationalCallout>
    </div>
  );
};
