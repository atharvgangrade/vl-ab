import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BarChart2,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Columns,
  Copy,
  Hash,
  HelpCircle,
  Layers,
  Search,
  Table as TableIcon,
} from 'lucide-react';
import { ColumnProfile, DatasetPreviewResponse, DatasetProfile } from '../types';
import { api } from '../services/api';
import { EducationalCallout } from './EducationalCallout';

interface DatasetInspectionProps {
  profile: DatasetProfile;
  onProceed: () => void;
  onUpdateInferredType?: (columnName: string, newType: string) => void;
}

export const DatasetInspection: React.FC<DatasetInspectionProps> = ({
  profile,
  onProceed,
  onUpdateInferredType,
}) => {
  const [selectedColumnName, setSelectedColumnName] = useState<string>(
    profile.columns[0]?.name || ''
  );
  const [previewData, setPreviewData] = useState<DatasetPreviewResponse | null>(null);
  const [previewPage, setPreviewPage] = useState(1);
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);
  const [tableSearch, setTableSearch] = useState('');

  // Fetch paginated preview
  useEffect(() => {
    let isMounted = true;
    const fetchPreview = async () => {
      setIsLoadingPreview(true);
      try {
        const res = await api.getDatasetPreview(profile.id, previewPage, 15);
        if (isMounted) setPreviewData(res);
      } catch (err) {
        console.error('Failed to load dataset preview', err);
      } finally {
        if (isMounted) setIsLoadingPreview(false);
      }
    };
    fetchPreview();
    return () => {
      isMounted = false;
    };
  }, [profile.id, previewPage]);

  const selectedColumn = profile.columns.find((c) => c.name === selectedColumnName) || profile.columns[0];

  // Total issues across all columns
  const allIssues = profile.columns.flatMap((c) =>
    c.issues.map((issue) => ({ column: c.name, issue }))
  );

  return (
    <div className="space-y-6">
      {/* Top Overview Bar */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-200 gap-3">
          <div>
            <span className="text-[11px] font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
              Stage 2 — Inspection & Profiling
            </span>
            <h2 className="text-base font-semibold text-slate-900 mt-1">
              Dataset Profile: {profile.name}
            </h2>
            <p className="text-xs text-slate-500">
              Format: <span className="font-mono uppercase font-semibold text-slate-700">{profile.format}</span> • Analyzed {profile.columns.length} columns and {profile.row_count.toLocaleString()} observations.
            </p>
          </div>

          <button
            type="button"
            onClick={onProceed}
            className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors shadow-sm self-start md:self-auto"
          >
            <span>Proceed to Feature Selection</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Stat Highlights */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-md border border-slate-200">
            <span className="text-slate-500 block mb-0.5">Total Observations</span>
            <span className="text-base font-semibold text-slate-900 font-mono">
              {profile.row_count.toLocaleString()}
            </span>
          </div>
          <div className="p-3 bg-slate-50 rounded-md border border-slate-200">
            <span className="text-slate-500 block mb-0.5">Total Features</span>
            <span className="text-base font-semibold text-slate-900 font-mono">
              {profile.column_count}
            </span>
          </div>
          <div className="p-3 bg-slate-50 rounded-md border border-slate-200">
            <span className="text-slate-500 block mb-0.5">Missing Values</span>
            <span
              className={`text-base font-semibold font-mono ${
                profile.has_missing_values ? 'text-amber-600' : 'text-emerald-700'
              }`}
            >
              {profile.has_missing_values ? 'Present' : 'None Detected'}
            </span>
          </div>
          <div className="p-3 bg-slate-50 rounded-md border border-slate-200">
            <span className="text-slate-500 block mb-0.5">Duplicate Rows</span>
            <span
              className={`text-base font-semibold font-mono ${
                profile.duplicate_row_count > 0 ? 'text-amber-600' : 'text-slate-900'
              }`}
            >
              {profile.duplicate_row_count}
            </span>
          </div>
        </div>

        {/* Diagnostic Observations */}
        {allIssues.length > 0 && (
          <div className="mt-4 p-3 bg-amber-50/70 border border-amber-200 rounded-md text-xs text-amber-900">
            <div className="flex items-center gap-1.5 font-semibold text-amber-800 mb-1">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Automated Diagnostics & Quality Observations ({allIssues.length})</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 text-amber-800 text-[11px] pl-1">
              {allIssues.slice(0, 5).map((item, idx) => (
                <li key={idx}>
                  <strong>{item.column}</strong>: {item.issue}
                </li>
              ))}
              {allIssues.length > 5 && (
                <li className="text-slate-500 italic">
                  + {allIssues.length - 5} additional quality observations listed in column profiler below.
                </li>
              )}
            </ul>
          </div>
        )}
      </div>

      {/* Main Column Profiling Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Column List Selector (Left) */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 lg:col-span-1">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
              Columns ({profile.columns.length})
            </h3>
            <span className="text-[11px] text-slate-400">Click to profile</span>
          </div>

          <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-1">
            {profile.columns.map((col) => {
              const isSelected = col.name === selectedColumnName;
              return (
                <button
                  key={col.name}
                  type="button"
                  onClick={() => setSelectedColumnName(col.name)}
                  className={`w-full text-left p-2.5 rounded-md border text-xs transition-colors flex items-center justify-between ${
                    isSelected
                      ? 'border-indigo-500 bg-indigo-50/50 text-indigo-950 font-medium'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="truncate mr-2">
                    <span className="block truncate font-medium">{col.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {col.missing_count > 0 ? `${col.missing_percentage}% missing` : '100% complete'}
                    </span>
                  </div>

                  <span
                    className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded border shrink-0 ${
                      col.inferred_type === 'numeric'
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : col.inferred_type === 'categorical'
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : col.inferred_type === 'boolean'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {col.inferred_type}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Column Deep Profile (Right 2 cols) */}
        {selectedColumn && (
          <div className="bg-white border border-slate-200 rounded-lg p-5 lg:col-span-2">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900 font-mono">
                    {selectedColumn.name}
                  </h3>
                  <span className="text-[10px] uppercase font-semibold font-mono px-2 py-0.5 rounded border bg-indigo-50 text-indigo-700 border-indigo-200">
                    Inferred: {selectedColumn.inferred_type}
                  </span>
                </div>
                <span className="text-xs text-slate-500">
                  Data type: <code className="font-mono text-slate-700">{selectedColumn.dtype}</code> • {selectedColumn.unique_count} distinct values ({selectedColumn.unique_percentage}%)
                </span>
              </div>

              {selectedColumn.issues.length > 0 && (
                <span className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-1 rounded">
                  {selectedColumn.issues.length} observation(s)
                </span>
              )}
            </div>

            {/* Warnings for this column */}
            {selectedColumn.issues.length > 0 && (
              <div className="mb-4 p-2.5 rounded bg-amber-50/50 border border-amber-200 text-xs text-amber-800 space-y-1">
                {selectedColumn.issues.map((iss, i) => (
                  <p key={i}>• {iss}</p>
                ))}
              </div>
            )}

            {/* Numerical Stats or Categorical Distribution */}
            {selectedColumn.inferred_type === 'numeric' && selectedColumn.numeric_stats ? (
              <div>
                <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Descriptive Statistical Distribution
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">MEAN</span>
                    <span className="font-semibold text-slate-900">{selectedColumn.numeric_stats.mean}</span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">MEDIAN (Q2)</span>
                    <span className="font-semibold text-slate-900">{selectedColumn.numeric_stats.median}</span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">STD DEV (σ)</span>
                    <span className="font-semibold text-slate-900">{selectedColumn.numeric_stats.std}</span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">MIN — MAX</span>
                    <span className="font-semibold text-slate-900">
                      {selectedColumn.numeric_stats.min} → {selectedColumn.numeric_stats.max}
                    </span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">Q25 (25th %)</span>
                    <span className="font-semibold text-slate-900">{selectedColumn.numeric_stats.q25}</span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">Q75 (75th %)</span>
                    <span className="font-semibold text-slate-900">{selectedColumn.numeric_stats.q75}</span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">IQR</span>
                    <span className="font-semibold text-slate-900">
                      {(selectedColumn.numeric_stats.q75 - selectedColumn.numeric_stats.q25).toFixed(4)}
                    </span>
                  </div>
                  <div className="p-2.5 rounded border border-slate-200 bg-slate-50">
                    <span className="text-slate-400 block text-[10px]">MISSING ROWS</span>
                    <span className="font-semibold text-slate-900">
                      {selectedColumn.missing_count} ({selectedColumn.missing_percentage}%)
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <h4 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Category Frequency Breakdown (Top Distinct Values)
                </h4>
                {selectedColumn.top_categories && selectedColumn.top_categories.length > 0 ? (
                  <div className="space-y-2">
                    {selectedColumn.top_categories.map((cat, i) => (
                      <div key={i} className="text-xs">
                        <div className="flex justify-between text-slate-700 mb-0.5">
                          <span className="font-mono font-medium truncate max-w-[200px]">
                            {cat.value}
                          </span>
                          <span className="font-mono text-slate-500">
                            {cat.count} ({cat.percentage}%)
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-indigo-600 h-1.5 rounded-full"
                            style={{ width: `${Math.min(cat.percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No distinct categories available.</p>
                )}
              </div>
            )}

            {/* Sample values preview */}
            <div className="mt-5 pt-4 border-t border-slate-100">
              <span className="text-xs font-semibold text-slate-700 block mb-1">
                Sample Values (First 5 Non-Null)
              </span>
              <div className="flex flex-wrap gap-1.5 font-mono text-xs">
                {selectedColumn.sample_values.map((v, i) => (
                  <span
                    key={i}
                    className="bg-slate-100 border border-slate-200 text-slate-800 px-2 py-0.5 rounded"
                  >
                    {v !== null ? String(v) : '<null>'}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Paginated Dataset Table Preview */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
          <div className="flex items-center gap-2">
            <TableIcon className="w-4 h-4 text-slate-600" />
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
              Tabular Inspection Grid
            </h3>
            <span className="text-xs text-slate-400">
              (Page {previewData?.page || 1} of {previewData?.total_pages || 1})
            </span>
          </div>

          {/* Pagination controls */}
          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              disabled={previewPage <= 1 || isLoadingPreview}
              onClick={() => setPreviewPage((p) => Math.max(1, p - 1))}
              className="flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <span className="font-mono text-slate-600 text-xs px-1">
              {previewPage} / {previewData?.total_pages || 1}
            </span>
            <button
              type="button"
              disabled={
                previewPage >= (previewData?.total_pages || 1) || isLoadingPreview
              }
              onClick={() => setPreviewPage((p) => p + 1)}
              className="flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto mt-3 border border-slate-100 rounded">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700">
                <th className="p-2 font-mono text-[11px] text-slate-400 w-12 text-center">#</th>
                {previewData?.columns.map((col) => (
                  <th key={col} className="p-2 font-semibold border-r border-slate-200 truncate">
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {previewData?.rows.map((row, rIdx) => {
                const globalRowNumber = ((previewData.page - 1) * previewData.page_size) + rIdx + 1;
                return (
                  <tr key={rIdx} className="border-b border-slate-100 hover:bg-slate-50/50">
                    <td className="p-2 font-mono text-[11px] text-slate-400 text-center bg-slate-50/30">
                      {globalRowNumber}
                    </td>
                    {previewData.columns.map((col) => {
                      const val = row[col];
                      return (
                        <td key={col} className="p-2 border-r border-slate-100 font-mono truncate max-w-[180px]">
                          {val === null || val === undefined ? (
                            <span className="text-rose-500 italic text-[11px]">NaN</span>
                          ) : (
                            String(val)
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Educational Callout */}
      <EducationalCallout title="Machine Learning Concept: Why is data profiling critical before modeling?">
        <p className="mb-2">
          Real datasets frequently suffer from hidden pathologies: missing observations, zero-variance features, high-cardinality categorical variables, or target leakage.
        </p>
        <p>
          Linear regression assumes your features have non-zero variance and that predictors are free of extreme collinearity. Understanding your feature distributions at this stage informs how you should impute, scale, and encode your variables in the next steps.
        </p>
      </EducationalCallout>
    </div>
  );
};
