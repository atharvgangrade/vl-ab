import React from 'react';
import { Check, ChevronRight, History, X } from 'lucide-react';
import { ExperimentHistoryItem } from '../types';

interface ExperimentHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  experiments: ExperimentHistoryItem[];
  onSelectExperiment: (experimentId: string) => void;
  currentExperimentId?: string;
}

export const ExperimentHistoryModal: React.FC<ExperimentHistoryModalProps> = ({
  isOpen,
  onClose,
  experiments,
  onSelectExperiment,
  currentExperimentId,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg border border-slate-200 max-w-2xl w-full p-5 shadow-2xl flex flex-col max-h-[85vh]">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-700" />
            <h3 className="text-sm font-semibold text-slate-900">
              Experiment History & Comparative Records
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto py-3 space-y-2 flex-1">
          {experiments.length > 0 ? (
            experiments.map((exp) => {
              const isCurrent = exp.experiment_id === currentExperimentId;
              const dateStr = new Date(exp.created_at).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={exp.experiment_id}
                  onClick={() => {
                    onSelectExperiment(exp.experiment_id);
                    onClose();
                  }}
                  className={`p-3 rounded-lg border text-xs cursor-pointer transition-colors flex items-center justify-between ${
                    isCurrent
                      ? 'border-indigo-500 bg-indigo-50/50 text-indigo-950 font-medium'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-semibold text-slate-900">{exp.name}</span>
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded border bg-slate-100 text-slate-600">
                        {exp.model_type}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Dataset: {exp.dataset_id} • Time: {dateStr}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-right font-mono">
                    <div>
                      <span className="text-[10px] text-slate-400 block">R² Test</span>
                      <span
                        className={`font-bold ${
                          exp.r2_test !== null && exp.r2_test >= 0.5
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {exp.r2_test !== null ? exp.r2_test.toFixed(4) : 'N/A'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">RMSE</span>
                      <span className="font-bold text-slate-800">
                        {exp.rmse_test !== null ? exp.rmse_test.toLocaleString() : 'N/A'}
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8 text-xs text-slate-400 italic">
              No previous experiments recorded yet. Train a model to begin logging experiments.
            </div>
          )}
        </div>

        <div className="pt-3 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
