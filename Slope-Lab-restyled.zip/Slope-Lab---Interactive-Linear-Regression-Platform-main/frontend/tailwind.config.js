/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#f4f6f3',
        surface: '#ffffff',
        'surface-subtle': '#eaeee9',
        border: '#d9dfd6',
        'border-strong': '#bcc5b8',
        // Graphite: neutral ramp with a faint green cast, like pencil on graph paper
        slate: {
          50: '#f4f6f3', 100: '#eaeee9', 200: '#d9dfd6', 300: '#bcc5b8', 400: '#8e9a8a',
          500: '#66736a', 600: '#4b574f', 700: '#36413a', 800: '#232c27', 900: '#151c18', 950: '#0c110e',
          850: '#1b231f',
        },
        // Primary: deep teal ink (replaces indigo)
        indigo: {
          50: '#e8f6f3', 100: '#c9ece5', 200: '#9bdacf', 300: '#62c1b2', 400: '#2fa593',
          500: '#148a79', 600: '#0b7164', 700: '#0a5a50', 800: '#0b4841', 900: '#0a3b35', 950: '#05221f',
        },
        primary: {
          50: '#e8f6f3', 100: '#c9ece5', 200: '#9bdacf', 300: '#62c1b2', 400: '#2fa593',
          500: '#148a79', 600: '#0b7164', 700: '#0a5a50', 800: '#0b4841', 900: '#0a3b35', 950: '#05221f',
        },
        // Success: olive green, distinct from the teal primary
        emerald: {
          50: '#f3f7e6', 100: '#e4eec3', 200: '#cfe093', 300: '#b3cc5c', 400: '#92b032',
          500: '#739518', 600: '#5c7a12', 700: '#486010', 800: '#394c10', 900: '#2f3f10',
        },
        // Warnings: highlighter yellow
        amber: {
          50: '#fff9de', 100: '#fff0a8', 200: '#ffe46e', 300: '#fdd43a', 400: '#f5c000',
          500: '#dba500', 600: '#b38300', 700: '#8c6500', 800: '#6d4e04', 900: '#573e07',
        },
        // Errors / residuals: red-pencil vermilion
        rose: {
          50: '#fff1ed', 100: '#ffdfd6', 200: '#ffc0b0', 300: '#ff9a82', 400: '#f46d4d',
          500: '#e24a2b', 600: '#c93719', 700: '#a52b13', 800: '#862813', 900: '#6f2613',
        },
      },
      fontFamily: {
        sans: ['"IBM Plex Sans"', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        display: ['"Bricolage Grotesque"', '"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'Consolas', 'monospace'],
      },
      borderRadius: {
        xs: '1px',
        DEFAULT: '2px',
        sm: '2px',
        md: '3px',
        lg: '4px',
        xl: '6px',
        '2xl': '8px',
      },
      boxShadow: {
        xs: '0 1px 0 0 rgb(21 28 24 / 0.08)',
        sm: '0 1px 0 0 rgb(21 28 24 / 0.14)',
        lg: '4px 4px 0 0 rgb(21 28 24 / 0.9)',
        xl: '6px 6px 0 0 rgb(21 28 24 / 0.9)',
        '2xl': '8px 8px 0 0 rgb(21 28 24 / 0.9)',
      },
    },
  },
  plugins: [],
}
